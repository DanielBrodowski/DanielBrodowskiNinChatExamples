﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace CircusTrein.Tests
{
    [TestClass]
    public class WagonTests
    {
        private Wagon _wagon;

        [TestInitialize]
        public void NewWagon()
        {
            _wagon = new Wagon();
        }

        [TestMethod]
        public void Is_Wagon_Craeted_And_Capped()
        {
            //Arrange
            Wagon w = new Wagon();

            //Act


            //Assert
            Assert.IsNotNull(w);

            Assert.AreEqual(10, w.maxSize);

        }

        [TestMethod]
        public void Wagon_Can_Take_Animal()
        {
            //Arrange 


            //Act
            var result = _wagon.AddAnimalToWagon(AnimalFactory.LargeHerbivore);

            //Assert 
            Assert.IsTrue(result);
        }

        [TestMethod]
        public void Wagon_Can_Fit_Animal()
        {
            //Arrange 


            //Act
            var result = _wagon.CanFitAnimal(AnimalFactory.LargeCarnivore);

            //Assert
            Assert.IsTrue(result);
        }

        [TestMethod]
        public void Full_Wagon_Cant_Take_More_Animals()
        {
            //Arrange 
            Wagon w = new Wagon();
            w.AddAnimalToWagon(AnimalFactory.LargeHerbivore);
            w.AddAnimalToWagon(AnimalFactory.LargeHerbivore);

            //Act
            var result = w.CanFitAnimal(AnimalFactory.SmallHerbivore);

            //Assert
            Assert.IsFalse(result);
        }

        [TestMethod]
        public void Animal_Is_Added_When_Safe()
        {
            //Arrange 


            //Act
            var result = _wagon.IsSafe(AnimalFactory.LargeCarnivore);

            //Assert
            Assert.IsTrue(result);
        }

        [TestMethod]
        public void Animal_Is_Not_Added_When_Unsafe()
        {
            //Arrange 
            _wagon.AddAnimalToWagon(AnimalFactory.LargeCarnivore);

            //Act
            var result = _wagon.IsSafe(AnimalFactory.LargeCarnivore);

            //Assert
            Assert.IsFalse(result);
        }

        //[TestMethod]
        //public void Checking_Empty_Animal_For_Safety()
        //{
        //    //Arrange 
        //    Animal testAnimal = new Animal();
        //    testAnimal.Size = 0;

        //    //Act
        //    _wagon.IsSafe()

        //    //Assert

        //}

        [TestMethod]
        public void Is_SpaceLeft_Being_Calculated()
        {
            //Arrange
            Animal a = AnimalFactory.LargeCarnivore;
            int setCap = _wagon.maxSize;
            int aSize = (int)a.Size;

            int expectedCap = setCap - aSize;

            //Act
            _wagon.AddAnimalToWagon(a);
            int currentCap = _wagon.SpaceLeft();

            //Assert
            Assert.AreEqual(expectedCap, currentCap);
        }

    }
}
