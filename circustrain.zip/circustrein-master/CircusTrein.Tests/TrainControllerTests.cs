﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace CircusTrein.Tests
{
    [TestClass]
    public class TrainControllerTests
    {
        [TestMethod]
        public void No_Wagons_If_There_Is_No_Animals()
        {
            //Arrange
            TrainController t = new TrainController();
            int expectedOutcome = 0;

            //Act
            var result = t.GetWagons();

            //Assert
            Assert.AreEqual(expectedOutcome, result.Count);
        }

        [TestMethod]
        public void Wagon_Created_If_There_Is_An_Animal()
        {
            //Arrange
            TrainController t = new TrainController();            
            

            //Act
            t.CreateWagons(AnimalFactory.SmallAnimalList());
            var result = t.GetWagons();

            //Assert
            Assert.IsTrue(result.Count > 0);
        }

        [TestMethod]
        public void New_Wagon_Created_If_Current_Is_Full()
        {
            //Arrange
            TrainController t = new TrainController();
            t.CreateWagons(AnimalFactory.MediumAnimalList());


            //Act
            t.CreateWagons(AnimalFactory.MediumAnimalList());
            var result = t.GetWagons();

            //Assert
            Assert.IsTrue(result.Count > 1);
        }

    }
}
