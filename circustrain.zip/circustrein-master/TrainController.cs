﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CircusTrein
{
    public class TrainController
    {
        private List<Wagon> wagons = new List<Wagon>();

        public void CreateWagons(List<Animal> animalQueue)
        {
            animalQueue = animalQueue.OrderByDescending(x => x.Size).ThenByDescending(x => x.Type == AnimalType.Carnivore).ToList();

            foreach (var animal in animalQueue)
            {
                CreateWagon(animal);
            }

        }

        private void CreateWagon(Animal animal)
        {
            if (wagons.Count == 0)
            {
                wagons.Add(new Wagon());
            }

            PopulateWagons(animal);
        }

        private void PopulateWagons(Animal animal)
        {
            for (int i = 0; i < wagons.Count; i++)
            {
                if (wagons[i].AddAnimalToWagon(animal))
                {
                    break;
                }
                else if (i != wagons.Count - 1) continue;
                {
                    wagons.Add(new Wagon());
                    wagons[wagons.Count - 1].AddAnimalToWagon(animal);
                    break;
                }
            }
        }

        public List<Wagon> GetWagons()
        {
            return wagons;
        }

    }
}
