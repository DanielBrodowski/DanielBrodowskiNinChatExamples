﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CircusTrein
{
    public partial class Form1 : Form
    {
        TrainController trainController = new TrainController();

        public Form1()
        {
            InitializeComponent();
        }

        List<Animal> animals = new List<Animal>();

        private AnimalSize SelectedSize()
        {
            if (AnimalMediumRadioButton.Checked == true) return AnimalSize.Medium;
            else if (AnimalLargeRadioButton.Checked == true) return AnimalSize.Large;
            else return AnimalSize.Small;

        }

        private AnimalType SelectedType()
        {
            if (carnivoreRadioButton.Checked == true) return AnimalType.Carnivore;
            else return AnimalType.Herbivore;
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void addAnimalBtn_Click(object sender, EventArgs e)
        {
            if (animalNameTextBox.Text.Length <= 0)
            {
                MessageBox.Show("Please enter name of the animal");
                return;
            }
            if (AnimalSmallRadioButton.Checked != true && AnimalMediumRadioButton.Checked != true && AnimalLargeRadioButton.Checked != true)
            {
                MessageBox.Show("Pease select the animal's size");
                return;
            }
            if (carnivoreRadioButton.Checked != true && herbivoreRadioButton.Checked != true)
            {
                MessageBox.Show("Please select the animal type");
                return;
            }

            animals.Add(new Animal(animalNameTextBox.Text, SelectedSize(), SelectedType()));

            currentAnimalsTextBox.Clear();

            foreach (var animal in animals)
            {
                currentAnimalsTextBox.Text += animal + "\r\n";
            }

        }

        private void createWagonBtn_Click(object sender, EventArgs e)
        {
            Stopwatch timer = Stopwatch.StartNew();

            wagonTextBox.Text = null;

            trainController.CreateWagons(animals);

            var wagons = trainController.GetWagons();

            for (int i = 0; i < wagons.Count; i++)
            {
                wagonTextBox.Text += "Wagon" + (i + 1) + "\r\n";
                foreach (var animal in wagons[i].GetAnimalList())
                {
                    wagonTextBox.Text += animal + "\r\n";
                }

                wagonTextBox.Text += "\r\n";
            }

            timer.Stop();
            TimeSpan timespan = timer.Elapsed;

            timeTextBox.Text = String.Format("{0:00}:{1:00}:{2:000}", timespan.Minutes, timespan.Seconds, timespan.Milliseconds);

        }
    }
}
