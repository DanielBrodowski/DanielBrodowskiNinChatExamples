﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CircusTrein
{
   public class Wagon
    {
        private List<Animal> animalsInside = new List<Animal>();
        //Public only due to testing, normally private 
        public int maxSize = 10;

        public bool CanFitAnimal(Animal animalToAdd)
        {
            if (SpaceLeft() < animalToAdd.GetSize())
            {
                return false;
            }

            return true;
        }

        //public only for tesing! otherwise private
        public bool IsSafe(Animal animalToAdd)
        {
            if (animalsInside.FindIndex(a => a.Type == AnimalType.Carnivore && a.Size >= animalToAdd.Size) > -1)
            {
                return false;
            }

            if (animalsInside.FindIndex(a => a.Size <= animalToAdd.Size && animalToAdd.Type == AnimalType.Carnivore) > -1)
            {
                return false;
            }

            return true;
        }

        //public only for testing!
        public int SpaceLeft()
        {
            int size = maxSize;

            foreach (var animal in animalsInside)
            {
                size -= animal.GetSize();
            }

            return size;
        }

        public bool AddAnimalToWagon(Animal animalToAdd)
        {
            if (CanFitAnimal(animalToAdd) && IsSafe(animalToAdd))
            {
                animalsInside.Add(animalToAdd);
                return true;
            }

            return false;
        }

        public override string ToString()
        {
            string result = "";

            foreach (var animal in animalsInside)
            {
                result = animal.ToString();
            }

            return result;
        }

        public IEnumerable<Animal> GetAnimalList()
        {
            return animalsInside.ToList();
        }
    }
}
