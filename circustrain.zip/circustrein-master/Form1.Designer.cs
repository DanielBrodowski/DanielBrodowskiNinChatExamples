﻿
namespace CircusTrein
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.animalNameLbl = new System.Windows.Forms.Label();
            this.animalNameTextBox = new System.Windows.Forms.TextBox();
            this.animalSizeGroupBox = new System.Windows.Forms.GroupBox();
            this.AnimalLargeRadioButton = new System.Windows.Forms.RadioButton();
            this.AnimalMediumRadioButton = new System.Windows.Forms.RadioButton();
            this.AnimalSmallRadioButton = new System.Windows.Forms.RadioButton();
            this.AnimalTypeGroupBox = new System.Windows.Forms.GroupBox();
            this.herbivoreRadioButton = new System.Windows.Forms.RadioButton();
            this.carnivoreRadioButton = new System.Windows.Forms.RadioButton();
            this.addAnimalBtn = new System.Windows.Forms.Button();
            this.createWagonBtn = new System.Windows.Forms.Button();
            this.timeTextBox = new System.Windows.Forms.TextBox();
            this.timeLbl = new System.Windows.Forms.Label();
            this.currentAnimalsTextBox = new System.Windows.Forms.RichTextBox();
            this.currentAnimalsLbl = new System.Windows.Forms.Label();
            this.wagonTextBox = new System.Windows.Forms.RichTextBox();
            this.wagonLbl = new System.Windows.Forms.Label();
            this.animalSizeGroupBox.SuspendLayout();
            this.AnimalTypeGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // animalNameLbl
            // 
            this.animalNameLbl.AutoSize = true;
            this.animalNameLbl.Location = new System.Drawing.Point(77, 14);
            this.animalNameLbl.Name = "animalNameLbl";
            this.animalNameLbl.Size = new System.Drawing.Size(72, 13);
            this.animalNameLbl.TabIndex = 0;
            this.animalNameLbl.Text = "Animal Name:";
            // 
            // animalNameTextBox
            // 
            this.animalNameTextBox.Location = new System.Drawing.Point(80, 30);
            this.animalNameTextBox.Name = "animalNameTextBox";
            this.animalNameTextBox.Size = new System.Drawing.Size(100, 20);
            this.animalNameTextBox.TabIndex = 1;
            // 
            // animalSizeGroupBox
            // 
            this.animalSizeGroupBox.Controls.Add(this.AnimalLargeRadioButton);
            this.animalSizeGroupBox.Controls.Add(this.AnimalMediumRadioButton);
            this.animalSizeGroupBox.Controls.Add(this.AnimalSmallRadioButton);
            this.animalSizeGroupBox.Location = new System.Drawing.Point(208, 14);
            this.animalSizeGroupBox.Name = "animalSizeGroupBox";
            this.animalSizeGroupBox.Size = new System.Drawing.Size(108, 92);
            this.animalSizeGroupBox.TabIndex = 2;
            this.animalSizeGroupBox.TabStop = false;
            this.animalSizeGroupBox.Text = "Size of the animal:";
            // 
            // AnimalLargeRadioButton
            // 
            this.AnimalLargeRadioButton.AutoSize = true;
            this.AnimalLargeRadioButton.Location = new System.Drawing.Point(7, 66);
            this.AnimalLargeRadioButton.Name = "AnimalLargeRadioButton";
            this.AnimalLargeRadioButton.Size = new System.Drawing.Size(52, 17);
            this.AnimalLargeRadioButton.TabIndex = 2;
            this.AnimalLargeRadioButton.TabStop = true;
            this.AnimalLargeRadioButton.Text = "Large";
            this.AnimalLargeRadioButton.UseVisualStyleBackColor = true;
            // 
            // AnimalMediumRadioButton
            // 
            this.AnimalMediumRadioButton.AutoSize = true;
            this.AnimalMediumRadioButton.Location = new System.Drawing.Point(7, 43);
            this.AnimalMediumRadioButton.Name = "AnimalMediumRadioButton";
            this.AnimalMediumRadioButton.Size = new System.Drawing.Size(62, 17);
            this.AnimalMediumRadioButton.TabIndex = 1;
            this.AnimalMediumRadioButton.TabStop = true;
            this.AnimalMediumRadioButton.Text = "Medium";
            this.AnimalMediumRadioButton.UseVisualStyleBackColor = true;
            // 
            // AnimalSmallRadioButton
            // 
            this.AnimalSmallRadioButton.AutoSize = true;
            this.AnimalSmallRadioButton.Location = new System.Drawing.Point(7, 20);
            this.AnimalSmallRadioButton.Name = "AnimalSmallRadioButton";
            this.AnimalSmallRadioButton.Size = new System.Drawing.Size(50, 17);
            this.AnimalSmallRadioButton.TabIndex = 0;
            this.AnimalSmallRadioButton.TabStop = true;
            this.AnimalSmallRadioButton.Text = "Small";
            this.AnimalSmallRadioButton.UseVisualStyleBackColor = true;
            // 
            // AnimalTypeGroupBox
            // 
            this.AnimalTypeGroupBox.Controls.Add(this.herbivoreRadioButton);
            this.AnimalTypeGroupBox.Controls.Add(this.carnivoreRadioButton);
            this.AnimalTypeGroupBox.Location = new System.Drawing.Point(208, 112);
            this.AnimalTypeGroupBox.Name = "AnimalTypeGroupBox";
            this.AnimalTypeGroupBox.Size = new System.Drawing.Size(108, 66);
            this.AnimalTypeGroupBox.TabIndex = 3;
            this.AnimalTypeGroupBox.TabStop = false;
            this.AnimalTypeGroupBox.Text = "Animal Type:";
            // 
            // herbivoreRadioButton
            // 
            this.herbivoreRadioButton.AutoSize = true;
            this.herbivoreRadioButton.Location = new System.Drawing.Point(7, 43);
            this.herbivoreRadioButton.Name = "herbivoreRadioButton";
            this.herbivoreRadioButton.Size = new System.Drawing.Size(71, 17);
            this.herbivoreRadioButton.TabIndex = 1;
            this.herbivoreRadioButton.TabStop = true;
            this.herbivoreRadioButton.Text = "Herbivore";
            this.herbivoreRadioButton.UseVisualStyleBackColor = true;
            // 
            // carnivoreRadioButton
            // 
            this.carnivoreRadioButton.AutoSize = true;
            this.carnivoreRadioButton.Location = new System.Drawing.Point(7, 20);
            this.carnivoreRadioButton.Name = "carnivoreRadioButton";
            this.carnivoreRadioButton.Size = new System.Drawing.Size(70, 17);
            this.carnivoreRadioButton.TabIndex = 0;
            this.carnivoreRadioButton.TabStop = true;
            this.carnivoreRadioButton.Text = "Carnivore";
            this.carnivoreRadioButton.UseVisualStyleBackColor = true;
            // 
            // addAnimalBtn
            // 
            this.addAnimalBtn.Location = new System.Drawing.Point(80, 126);
            this.addAnimalBtn.Name = "addAnimalBtn";
            this.addAnimalBtn.Size = new System.Drawing.Size(100, 23);
            this.addAnimalBtn.TabIndex = 4;
            this.addAnimalBtn.Text = "Add Animal";
            this.addAnimalBtn.UseVisualStyleBackColor = true;
            this.addAnimalBtn.Click += new System.EventHandler(this.addAnimalBtn_Click);
            // 
            // createWagonBtn
            // 
            this.createWagonBtn.Location = new System.Drawing.Point(80, 155);
            this.createWagonBtn.Name = "createWagonBtn";
            this.createWagonBtn.Size = new System.Drawing.Size(100, 23);
            this.createWagonBtn.TabIndex = 5;
            this.createWagonBtn.Text = "Create Wagons";
            this.createWagonBtn.UseVisualStyleBackColor = true;
            this.createWagonBtn.Click += new System.EventHandler(this.createWagonBtn_Click);
            // 
            // timeTextBox
            // 
            this.timeTextBox.Location = new System.Drawing.Point(80, 209);
            this.timeTextBox.Name = "timeTextBox";
            this.timeTextBox.Size = new System.Drawing.Size(236, 20);
            this.timeTextBox.TabIndex = 6;
            // 
            // timeLbl
            // 
            this.timeLbl.AutoSize = true;
            this.timeLbl.Location = new System.Drawing.Point(77, 193);
            this.timeLbl.Name = "timeLbl";
            this.timeLbl.Size = new System.Drawing.Size(30, 13);
            this.timeLbl.TabIndex = 7;
            this.timeLbl.Text = "Time";
            // 
            // currentAnimalsTextBox
            // 
            this.currentAnimalsTextBox.Location = new System.Drawing.Point(436, 30);
            this.currentAnimalsTextBox.Name = "currentAnimalsTextBox";
            this.currentAnimalsTextBox.Size = new System.Drawing.Size(316, 199);
            this.currentAnimalsTextBox.TabIndex = 8;
            this.currentAnimalsTextBox.Text = "";
            // 
            // currentAnimalsLbl
            // 
            this.currentAnimalsLbl.AutoSize = true;
            this.currentAnimalsLbl.Location = new System.Drawing.Point(433, 14);
            this.currentAnimalsLbl.Name = "currentAnimalsLbl";
            this.currentAnimalsLbl.Size = new System.Drawing.Size(83, 13);
            this.currentAnimalsLbl.TabIndex = 9;
            this.currentAnimalsLbl.Text = "Current Animals:";
            // 
            // wagonTextBox
            // 
            this.wagonTextBox.Location = new System.Drawing.Point(80, 287);
            this.wagonTextBox.Name = "wagonTextBox";
            this.wagonTextBox.Size = new System.Drawing.Size(672, 151);
            this.wagonTextBox.TabIndex = 10;
            this.wagonTextBox.Text = "";
            // 
            // wagonLbl
            // 
            this.wagonLbl.AutoSize = true;
            this.wagonLbl.Location = new System.Drawing.Point(77, 271);
            this.wagonLbl.Name = "wagonLbl";
            this.wagonLbl.Size = new System.Drawing.Size(50, 13);
            this.wagonLbl.TabIndex = 11;
            this.wagonLbl.Text = "Wagons:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.wagonLbl);
            this.Controls.Add(this.wagonTextBox);
            this.Controls.Add(this.currentAnimalsLbl);
            this.Controls.Add(this.currentAnimalsTextBox);
            this.Controls.Add(this.timeLbl);
            this.Controls.Add(this.timeTextBox);
            this.Controls.Add(this.createWagonBtn);
            this.Controls.Add(this.addAnimalBtn);
            this.Controls.Add(this.AnimalTypeGroupBox);
            this.Controls.Add(this.animalSizeGroupBox);
            this.Controls.Add(this.animalNameTextBox);
            this.Controls.Add(this.animalNameLbl);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.animalSizeGroupBox.ResumeLayout(false);
            this.animalSizeGroupBox.PerformLayout();
            this.AnimalTypeGroupBox.ResumeLayout(false);
            this.AnimalTypeGroupBox.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label animalNameLbl;
        private System.Windows.Forms.TextBox animalNameTextBox;
        private System.Windows.Forms.GroupBox animalSizeGroupBox;
        private System.Windows.Forms.RadioButton AnimalLargeRadioButton;
        private System.Windows.Forms.RadioButton AnimalMediumRadioButton;
        private System.Windows.Forms.RadioButton AnimalSmallRadioButton;
        private System.Windows.Forms.GroupBox AnimalTypeGroupBox;
        private System.Windows.Forms.RadioButton herbivoreRadioButton;
        private System.Windows.Forms.RadioButton carnivoreRadioButton;
        private System.Windows.Forms.Button addAnimalBtn;
        private System.Windows.Forms.Button createWagonBtn;
        private System.Windows.Forms.TextBox timeTextBox;
        private System.Windows.Forms.Label timeLbl;
        private System.Windows.Forms.RichTextBox currentAnimalsTextBox;
        private System.Windows.Forms.Label currentAnimalsLbl;
        private System.Windows.Forms.RichTextBox wagonTextBox;
        private System.Windows.Forms.Label wagonLbl;
    }
}

