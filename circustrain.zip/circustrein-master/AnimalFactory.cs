﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CircusTrein
{
   public class AnimalFactory
    {
        public static Animal SmallCarnivore => new Animal("SmallCarnivore", AnimalSize.Small, AnimalType.Carnivore);
        public static Animal MediumCarnivore => new Animal("MediumCarnivore", AnimalSize.Medium, AnimalType.Carnivore);
        public static Animal LargeCarnivore => new Animal("LargeCarnivore", AnimalSize.Large, AnimalType.Carnivore);

        public static Animal SmallHerbivore => new Animal("SmallHerbivore", AnimalSize.Small, AnimalType.Herbivore);
        public static Animal MediumHerbivore => new Animal("MediumHerbivore", AnimalSize.Medium, AnimalType.Herbivore);
        public static Animal LargeHerbivore => new Animal("LargeHerbivore", AnimalSize.Large, AnimalType.Herbivore);

        public static List<Animal> SmallAnimalList()
        {
            List<Animal> Animals = new List<Animal>();

            Animals.Add(SmallHerbivore);
            Animals.Add(SmallHerbivore);
            Animals.Add(SmallHerbivore);

            return Animals;
        }

        public static List<Animal> MediumAnimalList()
        {
            List<Animal> Animals = new List<Animal>();

            Animals.Add(MediumHerbivore);
            Animals.Add(MediumHerbivore);
            Animals.Add(MediumHerbivore);
            Animals.Add(MediumHerbivore);

            return Animals;
        }
    }
}
