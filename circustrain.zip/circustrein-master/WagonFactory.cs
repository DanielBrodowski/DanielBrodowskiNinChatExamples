﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CircusTrein
{
    public class WagonFactory
    {
        public static List<Wagon> FillTestWagons()
        {
            List<Wagon> Wagons = new List<Wagon>();

            Wagon wagon1 = new Wagon();
            Wagon wagon2 = new Wagon();
            Wagon wagon3 = new Wagon();
            Wagon wagon4 = new Wagon();
            Wagon wagon5 = new Wagon();
            Wagon wagon6 = new Wagon();
            Wagon wagon7 = new Wagon();
            Wagon wagon8 = new Wagon();
            Wagon wagon9 = new Wagon();
            Wagon wagon10 = new Wagon();

            wagon1.AddAnimalToWagon(AnimalFactory.LargeCarnivore);
            wagon2.AddAnimalToWagon(AnimalFactory.LargeCarnivore);
            wagon3.AddAnimalToWagon(AnimalFactory.LargeCarnivore);
            wagon4.AddAnimalToWagon(AnimalFactory.LargeCarnivore);
            wagon5.AddAnimalToWagon(AnimalFactory.LargeCarnivore);
            wagon6.AddAnimalToWagon(AnimalFactory.LargeCarnivore);
            wagon7.AddAnimalToWagon(AnimalFactory.LargeCarnivore);
            wagon8.AddAnimalToWagon(AnimalFactory.LargeCarnivore);
            wagon9.AddAnimalToWagon(AnimalFactory.LargeCarnivore);
            wagon10.AddAnimalToWagon(AnimalFactory.LargeCarnivore);

            Wagons.Add(wagon1);
            Wagons.Add(wagon2);
            Wagons.Add(wagon3);
            Wagons.Add(wagon4);
            Wagons.Add(wagon5);
            Wagons.Add(wagon6);
            Wagons.Add(wagon7);
            Wagons.Add(wagon8);
            Wagons.Add(wagon9);
            Wagons.Add(wagon10);

            return Wagons;
        }
    }
}
