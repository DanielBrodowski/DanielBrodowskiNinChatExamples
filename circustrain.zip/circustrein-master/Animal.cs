﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CircusTrein
{
    public enum AnimalSize { Small = 1, Medium = 3, Large = 5}
    public enum AnimalType { Carnivore, Herbivore }

    public class Animal
    {
        public string Name { get; private set; }
        public AnimalSize Size { get; private set; }
        public AnimalType Type { get; private set; }

        public Animal(string name, AnimalSize size, AnimalType type)
        {
            this.Name = name;
            this.Size = size;
            this.Type = type;
        }

        public Animal()
        {

        }

        public int GetSize()
        {
            return (int)Size;
        }

        public override string ToString()
        {
            return $"{Name} - {Size} - {Type}";
        }

    }
}
