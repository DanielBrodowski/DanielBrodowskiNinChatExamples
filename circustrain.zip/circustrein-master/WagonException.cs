﻿using System;
using System.Runtime.Serialization;

namespace CircusTrein
{
    [Serializable]
    internal class WagonException : Exception
    {
        public WagonException()
        {
        }

        public WagonException(string message) : base(message)
        {
        }

        public WagonException(string message, Exception innerException) : base(message, innerException)
        {
        }

        protected WagonException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}