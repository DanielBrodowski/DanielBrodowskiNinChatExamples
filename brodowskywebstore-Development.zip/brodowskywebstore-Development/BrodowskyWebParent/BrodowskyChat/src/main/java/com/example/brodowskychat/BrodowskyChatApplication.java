package com.example.brodowskychat;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BrodowskyChatApplication {

    public static void main(String[] args) {
        SpringApplication.run(BrodowskyChatApplication.class, args);
    }

}
