package com.brodowsky.admin.user;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.springframework.test.util.AssertionErrors.assertNotEquals;

public class PasswordEncoderTests {
    @Test
    public void testEncodePassword(){
        BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
        String passwordRaw = "password123";
        String encodedPassword = passwordEncoder.encode(passwordRaw);

        Assertions.assertNotEquals(encodedPassword, passwordRaw);
    }
}
