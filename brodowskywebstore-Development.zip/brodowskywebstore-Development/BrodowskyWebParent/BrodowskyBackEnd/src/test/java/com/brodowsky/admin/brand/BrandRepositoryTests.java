package com.brodowsky.admin.brand;

import com.brodowsky.admin.repository.brand.BrandRepository;
import com.brodowsky.admin.repository.category.CategoryRepository;
import com.brodowsky.common.entity.Brand;
import com.brodowsky.common.entity.Category;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.annotation.Rollback;

import static org.assertj.core.api.Assertions.assertThat;

@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
@Rollback()
public class BrandRepositoryTests {

    @Autowired
    private BrandRepository repo;
    private CategoryRepository categoryRepo;

    @Test
    public void CreateBrandTest(){
        Category laptops = new Category(5);
        Brand apple = new Brand("Apple");
        apple.getCategories().add(laptops);

        Brand savedBrand = repo.save(apple);

        assertThat(savedBrand).isNotNull();
        assertThat(savedBrand.getId()).isGreaterThan(0);
    }
}
