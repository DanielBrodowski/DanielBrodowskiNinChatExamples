package com.brodowsky.admin.user;

import com.brodowsky.admin.exceptions.UserNotFoundException;
import com.brodowsky.admin.repository.user.UserRepository;
import com.brodowsky.admin.service.user.UserService;
import com.brodowsky.common.entity.User;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

public class UserServiceTests {

    @InjectMocks
    UserService userService;

    @Mock
    UserRepository repo;

    @Before
    public void init(){
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testFindAllUsers(){

        List<User> list = new ArrayList<>();

        User userOne = new User("tested1@test.com", "test123", "FirstnameOne", "LastnameOne");
        User userTwo = new User("tested2@test.com", "test123", "FirstnameTwo", "LastnameTwo");
        User userThree = new User("tested3@test.com", "test123", "FirstnameThree", "LastnameThree");

        list.add(userOne);
        list.add(userTwo);
        list.add(userThree);

        when(repo.findAll()).thenReturn(list);

        //test
        List<User> userList = userService.listAll();

        assertEquals(3, userList.size());
        verify(repo, times(1)).findAll();
    }

    @Test
    public void testFindUserByEmail(){

        when(repo.getUserByEmail("test@user.com")).thenReturn(new User("test@user.com", "test123", "FirstnameOne", "LastnameOne"));

        User user = userService.getByEmail("test@user.com");

        assertEquals("test@user.com", user.getEmail());
        assertEquals("FirstnameOne", user.getFirstName());
        assertEquals("LastnameOne", user.getLastName());

    }

    @Test
    public void testSaveUser() throws UserNotFoundException {

        User testUser = new User("test@user.com", "test123", "FirstnameOne", "LastnameOne");

        repo.save(testUser);

        verify(repo, times(1)).save(testUser);
    }

}
