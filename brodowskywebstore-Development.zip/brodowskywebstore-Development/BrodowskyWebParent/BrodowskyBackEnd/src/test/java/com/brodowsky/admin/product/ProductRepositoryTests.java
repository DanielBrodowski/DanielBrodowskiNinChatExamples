package com.brodowsky.admin.product;

import com.brodowsky.admin.repository.Product.ProductRepository;
import com.brodowsky.common.entity.Brand;
import com.brodowsky.common.entity.Category;
import com.brodowsky.common.entity.Product;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.annotation.Rollback;

import java.util.Date;

import static org.assertj.core.api.Assertions.assertThat;

@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
@Rollback()
public class ProductRepositoryTests {

    @Autowired
    private ProductRepository repo;

    @Autowired
    private TestEntityManager entityManager;

    @Test
    public void testCreateProduct(){
        Brand brand = entityManager.find(Brand.class, 1);
        Category category = entityManager.find(Category.class, 3);

        Product product = new Product();
        product.setName("Test Stock");
        product.setAlias("Test");
        product.setDescriptionShort("Product stock test description");
        product.setDescriptionFull("full test description");

        product.setBrand(brand);
        product.setCategory(category);
        product.setEnabled(true);
        product.setInStock(true);

        product.setPrice(1899);
        product.setCreatedTime(new Date());
        product.setUpdatedTime(new Date());
        product.setMainImage("image.png");

        Product savedProduct = repo.save(product);

        assertThat(savedProduct).isNotNull();
        assertThat(savedProduct.getId()).isGreaterThan(0);
    }

    @Test
    public void testSaveProductWithDetails() {
        Integer productId = 1;
        Product product = repo.findById(productId).get();

        product.addDetail("Device Memory", "128 GB");
        product.addDetail("CPU Model", "MediaTek");
        product.addDetail("OS", "Android 10");

        Product savedProduct = repo.save(product);
        assertThat(savedProduct.getDetails()).isNotEmpty();
    }

}
