package com.brodowsky.admin.user;

import com.brodowsky.admin.repository.user.UserRepository;
import com.brodowsky.common.entity.Role;
import com.brodowsky.common.entity.User;
import com.google.common.collect.Iterables;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.test.annotation.Rollback;

import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;


@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)

//@Rollback(false)
public class UserRepositoryTests {

    @Autowired
    private UserRepository repo;

    @Autowired
    private TestEntityManager entityManager;

    @Test
    public void testCreateUserWithOneRole(){
        Role testRole = entityManager.find(Role.class, 1);
        User testUser = new User("tested@test.com", "test123", "testedFirstname", "testedLastname");
        testUser.addRole(testRole);

        User savedUser = repo.save(testUser);

        assertThat(savedUser.getId()).isGreaterThan(0);
    }

    @Test
    public void testCrateUserWithTwoRoles(){
        User testUser = new User("tested@test.com", "test123", "testedFirstname", "testedLastname");
        Role editorRole = new Role(3);
        Role assistantRole = new Role(5);

        testUser.addRole(editorRole);
        testUser.addRole(assistantRole);
        User savedUser = repo.save(testUser);

        assertThat(savedUser.getId()).isGreaterThan(0);
    }

    @Test
    public void testListAllUsers(){
        Iterable<User> userList = repo.findAll();

        int userAmount = Iterables.size(userList);

        assert(userAmount > 0);
    }

    @Test
    public void testGetUserById(){
        User testUser = repo.findById(5).get();

        System.out.println(testUser);

        assertThat(testUser).isNotNull();
    }

    @Test
    public void testUpdateUserDetails(){
        User testUser = repo.findById(5).get();
        String expectedMail = "newtest@test.com";

        testUser.setEmail(expectedMail);

        repo.save(testUser);
        String result = testUser.getEmail();

        assertEquals(result, expectedMail);
    }

    @Rollback(false)
    @Test
    public void testChangeUserRole(){
        User testUser = repo.findById(5).get();
        Role currentRole = testUser.getRole().stream().findFirst().get();
        Role expectedRole = new Role(2);

        testUser.getRole().remove(currentRole);
        testUser.addRole(expectedRole);
        repo.save(testUser);

        Role result = testUser.getRole().stream().findFirst().get();

        assertEquals(expectedRole, result);

    }

    @Test
    public void testSwitchUserStatus(){
        User testUser = repo.findById(5).get();
        boolean currentStatus = testUser.isEnabled();

        if (currentStatus){
            testUser.setEnabled(false);
        }
        if (!currentStatus){
            testUser.setEnabled(true);
        }

        assert(testUser.isEnabled() != currentStatus);
    }

    @Rollback(false)
    @Test
    public void testDeleteUser(){
        User testUser = new User("tested@test.com", "test123", "testedFirstname", "testedLastname");
        User savedUser = repo.save(testUser);
        int testUserId = testUser.getId();

        repo.delete(savedUser);
        Optional<User> foundUser = repo.findById(testUserId);
        boolean result = foundUser.isEmpty();

        assert(result);
    }

    @Rollback(false)
    @Test
    public void testGetUserByEmail(){
        String email = "test@test.com";

        User testUser = repo.getUserByEmail(email);
        String result = testUser.getEmail();

        assertEquals(email, result);
    }

    @Test
    public void testCountById(){
        int id = 5;
        int expected = 1;

        Long countById = repo.countById(id);

        assertEquals(expected, countById);
    }

    @Test
    public void testListFirstPage(){
        int pageNumber = 0;
        int pageSize = 4;

        Pageable pageable = PageRequest.of(pageNumber, pageSize);
        Page<User> page = repo.findAll(pageable);

        List<User> listUsers = page.getContent();
        listUsers.forEach(user -> System.out.println(user));


        assertThat(listUsers.size()).isEqualTo(pageSize);
    }

    @Test
    public void testSearchUser(){
        String keyword = "bruce";

        int pageNumber = 0;
        int pageSize = 4;

        Pageable pageable = PageRequest.of(pageNumber, pageSize);
        Page<User> page = repo.findAll(keyword, pageable);

        List<User> userList = page.getContent();
        userList.forEach(System.out::println);

        assertThat(userList.size()).isGreaterThan(0);
    }

}
