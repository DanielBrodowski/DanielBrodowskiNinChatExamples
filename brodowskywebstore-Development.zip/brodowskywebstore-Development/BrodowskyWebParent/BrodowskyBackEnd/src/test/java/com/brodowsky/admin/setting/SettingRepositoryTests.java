package com.brodowsky.admin.setting;

import com.brodowsky.admin.repository.setting.SettingRepository;
import com.brodowsky.common.entity.Setting;
import com.brodowsky.common.entity.SettingCategory;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.annotation.Rollback;

import static org.assertj.core.api.Assertions.assertThat;

@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
@Rollback(false)
public class SettingRepositoryTests {

    @Autowired
    SettingRepository repo;

    @Test
    public void testCreateGeneralSettings(){
        Setting siteName = new Setting("SITE_NAME", "ByBrodowski", SettingCategory.GENERAL);
        Setting savedSetting = repo.save(siteName);

        assertThat(savedSetting).isNotNull();

    }
}
