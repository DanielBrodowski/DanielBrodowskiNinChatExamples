package com.brodowsky.admin.controller.brand;

import com.brodowsky.admin.contract.brand.CategoryDTO;
import com.brodowsky.admin.contract.brand.IBrandService;
import com.brodowsky.admin.exceptions.BrandNotFoundException;
import com.brodowsky.admin.exceptions.BrandNotFoundRestException;
import com.brodowsky.admin.service.brand.BrandService;
import com.brodowsky.common.entity.Brand;
import com.brodowsky.common.entity.Category;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

@RestController
public class BrandRestController {

    private final IBrandService service;

    public BrandRestController(IBrandService service) {
        this.service = service;
    }

    @GetMapping("/Brands/{id}/Categories")
    public List<CategoryDTO> listCategoriesByBrand(@PathVariable(name = "id") Integer brandId) throws BrandNotFoundRestException {
        List<CategoryDTO> categoryDTOList = new ArrayList<>();

        try{
            Brand brand = service.get(brandId);
            Set<Category> categories = brand.getCategories();

            for (Category category : categories){
                CategoryDTO dto = new CategoryDTO(category.getId(), category.getName());
                categoryDTOList.add(dto);
            }

            return categoryDTOList;
        }catch (BrandNotFoundException exc){
            throw new BrandNotFoundRestException();
        }
    }
}
