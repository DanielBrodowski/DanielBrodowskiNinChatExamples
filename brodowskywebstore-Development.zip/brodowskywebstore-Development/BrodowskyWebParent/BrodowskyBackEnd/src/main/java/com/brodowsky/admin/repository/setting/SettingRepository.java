package com.brodowsky.admin.repository.setting;

import com.brodowsky.common.entity.Setting;
import org.springframework.data.repository.CrudRepository;

public interface SettingRepository extends CrudRepository<Setting, String> {
}
