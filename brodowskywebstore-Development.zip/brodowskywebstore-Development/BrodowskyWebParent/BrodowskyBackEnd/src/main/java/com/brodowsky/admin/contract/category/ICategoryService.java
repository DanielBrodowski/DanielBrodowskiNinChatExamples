package com.brodowsky.admin.contract.category;

import com.brodowsky.admin.exceptions.CategoryNotFoundException;
import com.brodowsky.admin.service.category.CategoryPageInfo;
import com.brodowsky.common.entity.Category;

import java.util.List;

public interface ICategoryService {

    List<Category> listByPage(CategoryPageInfo pageInfo, int pageNum, String sortDir, String keyword);
    List<Category> listCategoriesInForm();
    Category save(Category category);
    Category get(Integer id) throws CategoryNotFoundException;
    void deleteCategory(Integer id) throws CategoryNotFoundException;

}
