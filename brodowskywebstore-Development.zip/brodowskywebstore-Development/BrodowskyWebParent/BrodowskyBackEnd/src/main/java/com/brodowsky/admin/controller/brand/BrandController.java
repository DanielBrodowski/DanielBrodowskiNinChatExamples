package com.brodowsky.admin.controller.brand;

import com.brodowsky.admin.constants.PageableConstants;
import com.brodowsky.admin.contract.brand.IBrandService;
import com.brodowsky.admin.contract.category.ICategoryService;
import com.brodowsky.admin.exceptions.BrandNotFoundException;
import com.brodowsky.admin.exceptions.CategoryNotFoundException;
import com.brodowsky.admin.service.category.CategoryPageInfo;
import com.brodowsky.admin.utility.FileUploadUtil;
import com.brodowsky.common.entity.Brand;
import com.brodowsky.common.entity.Category;
import org.springframework.data.domain.Page;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.io.IOException;
import java.util.List;

@Controller
public class BrandController {

    private final IBrandService service;
    private final ICategoryService categoryService;

    public BrandController(IBrandService service, ICategoryService categoryService) {
        this.service = service;
        this.categoryService = categoryService;
    }

    @GetMapping("/Brands")
    public String listFirstPage(@Param("sortDir") String sortDir, Model model){
        return listByPage(1, sortDir, null, model);
    }

    @GetMapping("/Brands/Page/{pageNum}")
    public String listByPage(@PathVariable(name = "pageNum") int pageNum, @Param("sortDir") String sortDir,
                             @Param("keyword") String keyword, Model model){
        if (sortDir == null || sortDir.isEmpty()){
            sortDir = "asc";
        }

        Page<Brand> page = service.listByPage(pageNum, sortDir, keyword);
        List<Brand> brandList = page.getContent();

        long startCount = (pageNum - 1) * PageableConstants.brandsPerPage + 1L;
        long endCount = startCount + PageableConstants.brandsPerPage - 1L;
        if (endCount > page.getTotalElements()){
            endCount = page.getTotalElements();
        }

        String reverseSortDir = sortDir.equals("asc") ? "desc" : "asc";

        model.addAttribute("totalPages", page.getTotalPages());
        model.addAttribute("totalItems", page.getTotalElements());
        model.addAttribute("currentPage", pageNum);
        model.addAttribute("sortField", "name");
        model.addAttribute("sortDir", sortDir);
        model.addAttribute("keyword", keyword);
        model.addAttribute("reverseSortDir", reverseSortDir);
        model.addAttribute("brandList", brandList);
        model.addAttribute("startCount", startCount);
        model.addAttribute("endCount", endCount);

        return "brand/brands";
    }

    @GetMapping("/Brands/New")
    public String newBrand(Model model){
        List<Category> categoryList = categoryService.listCategoriesInForm();

        model.addAttribute("categoryList", categoryList);
        model.addAttribute("brand", new Brand());
        model.addAttribute("pageTitle", "New Brand");

        return "brand/brand_form";
    }

    @PostMapping("/Brands/Save")
    public String saveBrand(Brand brand, @RequestParam("fileImage")MultipartFile multipartFile,
                            RedirectAttributes redirectAttributes) throws IOException {
        if (!multipartFile.isEmpty()){
            String fileName = StringUtils.cleanPath(multipartFile.getOriginalFilename());
            brand.setLogo(fileName);

            Brand savedBrand = service.save(brand);
            String uploadDir = "../brand-images/" + savedBrand.getId();

            FileUploadUtil.cleanDirectory(uploadDir);
            FileUploadUtil.saveFile(uploadDir, fileName, multipartFile);
        } else {
            service.save(brand);
        }


        redirectAttributes.addFlashAttribute("message", "Brand has been saved.");
        return "redirect:/Brands";
    }

    @GetMapping("/Brands/Edit/{id}")
    public String updateBrand(@PathVariable(name = "id") Integer id, Model model, RedirectAttributes redirectAttributes){
        try{
            Brand brand = service.get(id);
            List<Category> categoryList = categoryService.listCategoriesInForm();

            model.addAttribute("brand", brand);
            model.addAttribute("categoryList", categoryList);
            model.addAttribute("pageTitle", "Edit Brand: " + id);

            return "brand/brand_form";
        } catch (BrandNotFoundException exc) {
            redirectAttributes.addFlashAttribute("message", exc.getMessage());

            return "redirect:/Brands";
        }
    }

    @GetMapping("/Brands/Delete/{id}")
    public String deleteBrand(@PathVariable(name = "id") Integer id, Model model, RedirectAttributes redirectAttributes){

        try{
            service.delete(id);
            String brandDir = "../brand-images/" + id;
            FileUploadUtil.removeDir(brandDir);

            redirectAttributes.addFlashAttribute("message", "Brand: " + id + " has been deleted");
        } catch (BrandNotFoundException exc) {
            redirectAttributes.addFlashAttribute("message", exc.getMessage());
        }

        return "redirect:/Brands";
    }

}
