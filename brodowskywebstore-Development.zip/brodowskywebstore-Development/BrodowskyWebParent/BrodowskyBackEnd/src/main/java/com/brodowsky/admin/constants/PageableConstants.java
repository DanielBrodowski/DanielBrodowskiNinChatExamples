package com.brodowsky.admin.constants;

public class PageableConstants {

    public static final int brandsPerPage = 5;
    public static final int categoriesPerPage = 5;
    public static final int usersPerPage = 5;
    public static final int productsPerPage = 5;

}
