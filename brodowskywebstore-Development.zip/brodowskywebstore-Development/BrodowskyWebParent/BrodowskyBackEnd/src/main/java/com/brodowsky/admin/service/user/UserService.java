package com.brodowsky.admin.service.user;

import com.brodowsky.admin.constants.PageableConstants;
import com.brodowsky.admin.contract.user.IUserService;
import com.brodowsky.admin.exceptions.BrandNotFoundException;
import com.brodowsky.admin.exceptions.UserNotFoundException;
import com.brodowsky.admin.repository.user.RoleRepository;
import com.brodowsky.admin.repository.user.UserRepository;
import com.brodowsky.common.entity.Brand;
import com.brodowsky.common.entity.Role;
import com.brodowsky.common.entity.User;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;

@Service
public class UserService implements IUserService {

    private final UserRepository userRepo;
    private final RoleRepository roleRepo;
    private final PasswordEncoder passwordEncoder;

    public UserService(UserRepository repo, RoleRepository roleRepo, PasswordEncoder passwordEncoder) {
        this.userRepo = repo;
        this.roleRepo = roleRepo;
        this.passwordEncoder = passwordEncoder;
    }

    public User getByEmail(String email){
        return userRepo.getUserByEmail(email);
    }

    public List<User> listAll(){
        return (List<User>) userRepo.findAll();
    }

    public Page<User> listByPage(int pageNum, String sortField, String sortDir, String keyword){
        Sort sort = Sort.by(sortField);

        if (sortDir.equals("asc")){
            sort = sort.ascending();
        }else if (sortDir.equals("desc")){
            sort = sort.descending();
        }

        Pageable pageable = PageRequest.of(pageNum - 1, PageableConstants.usersPerPage, sort);

        if (keyword != null){
            return userRepo.findAll(keyword, pageable);
        }

        return userRepo.findAll(pageable);
    }

    public List<Role> rolesList(){
        return (List<Role>) roleRepo.findAll();
    }

    public User save(User user) throws UserNotFoundException {
        boolean isUpdatingUser = (user.getId() != null);

        if (isUpdatingUser){

            Optional<User> optionalUser = userRepo.findById(user.getId());
            if (optionalUser.isEmpty()) {
                throw new UserNotFoundException("User with id: " + user.getId() + " could not be found");
            }

            User existingUser = optionalUser.get();
                if (user.getPassword().isEmpty()){
                    user.setPassword(existingUser.getPassword());
                }else{
                    encodePassword(user);
                }
        }else{
            encodePassword(user);
        }

        return userRepo.save(user);
    }

    //How to private in Interface?
    public void encodePassword(User user){
        String encodedPassword = passwordEncoder.encode(user.getPassword());
        user.setPassword(encodedPassword);
    }

    public User updateUserAccount(User userAccount) throws UserNotFoundException {

        Optional<User> user = userRepo.findById(userAccount.getId());
        if (user.isEmpty()) {
            throw new UserNotFoundException("User with id: " + userAccount.getId() + " could not be found");
        }

        User userInDb = user.get();

        if (!userAccount.getPassword().isEmpty()){
            userInDb.setPassword(userAccount.getPassword());
            encodePassword(userInDb);
        }

        if (userAccount.getPhoto() != null){
            userInDb.setPhoto(userAccount.getPhoto());
        }

        userInDb.setFirstName(userAccount.getFirstName());
        userInDb.setLastName(userAccount.getLastName());

        return userRepo.save(userInDb);
    }

    public boolean isEmailUnique(Integer id, String email){
        User userByEmail = userRepo.getUserByEmail(email);

        if (userByEmail == null) return true;

        boolean isUserNew = (id == null);

        if (isUserNew){
            if (userByEmail != null) return false;
        }else {
            if (!userByEmail.getId().equals(id)){
                return false;
            }
        }

        return true;
    }

    public User get(Integer id) throws UserNotFoundException {

        Optional<User> user = userRepo.findById(id);
        if (user.isEmpty()) {
            throw new UserNotFoundException("User with id: " + id + " could not be found");
        }
        return user.get();
    }

    public void deleteUser(int id) throws UserNotFoundException {
        Long countById = userRepo.countById(id);
        if (countById == null || countById == 0){
            throw new UserNotFoundException("User with id: " + id + " could not found");
        }

        userRepo.deleteById(id);
    }

}
