package com.brodowsky.admin.contract.brand;

import com.brodowsky.admin.exceptions.BrandNotFoundException;
import com.brodowsky.common.entity.Brand;
import org.springframework.data.domain.Page;

import java.util.List;

public interface IBrandService {

    List<Brand>listAll();
    Brand save(Brand brand);
    Brand get(Integer id) throws BrandNotFoundException;
    void delete(Integer id) throws BrandNotFoundException;
    Page<Brand> listByPage(int pageNum, String sortDir, String keyword);
}
