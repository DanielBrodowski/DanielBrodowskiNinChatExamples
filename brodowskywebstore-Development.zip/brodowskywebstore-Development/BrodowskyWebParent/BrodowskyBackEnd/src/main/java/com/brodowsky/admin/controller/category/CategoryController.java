package com.brodowsky.admin.controller.category;

import com.brodowsky.admin.constants.PageableConstants;
import com.brodowsky.admin.contract.category.ICategoryService;
import com.brodowsky.admin.exceptions.CategoryNotFoundException;
import com.brodowsky.admin.service.category.CategoryPageInfo;
import com.brodowsky.admin.utility.FileUploadUtil;
import com.brodowsky.common.entity.Category;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.io.IOException;
import java.util.List;

@Controller
public class CategoryController {

    private final ICategoryService service;

    public CategoryController(ICategoryService service) {
        this.service = service;
    }

    @GetMapping("/Categories")
    public String listFirstPage(@Param("sortDir") String sortDir, Model model){
        return listByPage(1, sortDir, null, model);

    }

    @GetMapping("/Categories/Page/{pageNum}")
    public String listByPage(@PathVariable(name = "pageNum") int pageNum, @Param("sortDir") String sortDir,
                             @Param("keyword") String keyword, Model model){
        if (sortDir == null || sortDir.isEmpty()){
            sortDir = "asc";
        }

        CategoryPageInfo pageInfo = new CategoryPageInfo();
        List<Category> categoryList = service.listByPage(pageInfo, pageNum, sortDir, keyword);

        long startCount = (pageNum - 1) * PageableConstants.categoriesPerPage + 1L;
        long endCount = startCount + PageableConstants.categoriesPerPage - 1L;
        if (endCount > pageInfo.getTotalElements()){
            endCount = pageInfo.getTotalElements();
        }

        String reverseSortDir = sortDir.equals("asc") ? "desc" : "asc";

        model.addAttribute("totalPages", pageInfo.getTotalPages());
        model.addAttribute("totalItems", pageInfo.getTotalElements());
        model.addAttribute("currentPage", pageNum);
        model.addAttribute("sortField", "name");
        model.addAttribute("sortDir", sortDir);
        model.addAttribute("keyword", keyword);
        model.addAttribute("reverseSortDir", reverseSortDir);
        model.addAttribute("categoryList", categoryList);
        model.addAttribute("startCount", startCount);
        model.addAttribute("endCount", endCount);

        return "category/categories";
    }

    @GetMapping("Categories/New")
    public String newCategory(Model model){
        List<Category> categoryList = service.listCategoriesInForm();

        model.addAttribute("category", new Category());
        model.addAttribute("pageTitle", "New Category");
        model.addAttribute("categoryList", categoryList);

        return "category/category_form";
    }

    @PostMapping("/Categories/Save")
    public String saveCategory(Category category, @RequestParam("fileImage") MultipartFile multipartFile,
                               RedirectAttributes redirectAttributes) throws IOException {
        if (!multipartFile.isEmpty()){
            String fileName = StringUtils.cleanPath(multipartFile.getOriginalFilename());
            category.setImage(fileName);

            Category savedCategory = service.save(category);
            String uploadDir = "../category-images/" + savedCategory.getId();

            FileUploadUtil.cleanDirectory(uploadDir);
            FileUploadUtil.saveFile(uploadDir, fileName, multipartFile);
        } else {
            service.save(category);
        }


        redirectAttributes.addFlashAttribute("message", "Category has been saved.");
        return "redirect:/Categories";
    }

    @GetMapping("/Categories/Edit/{id}")
    public String updateCategory(@PathVariable(name = "id") Integer id, Model model, RedirectAttributes redirectAttributes){
        try{
            Category category = service.get(id);
            List<Category> categoryList = service.listCategoriesInForm();

            model.addAttribute("category", category);
            model.addAttribute("categoryList", categoryList);
            model.addAttribute("pageTitle", "Edit Category: " + id);

            return "category/category_form";
        } catch (CategoryNotFoundException exc) {
            redirectAttributes.addFlashAttribute("message", exc.getMessage());

            return "redirect:/Categories";
        }
    }

    @GetMapping("/Categories/Delete/{id}")
    public String deleteCategory(@PathVariable(name = "id") Integer id, Model model, RedirectAttributes redirectAttributes){

        try{
            service.deleteCategory(id);
            String categoryDir = "../category-images/" + id;
            FileUploadUtil.removeDir(categoryDir);

            redirectAttributes.addFlashAttribute("message", "Category: " + id + " has been deleted");
        } catch (CategoryNotFoundException exc) {
            redirectAttributes.addFlashAttribute("message", exc.getMessage());
        }

        return "redirect:/Categories";
    }

}
