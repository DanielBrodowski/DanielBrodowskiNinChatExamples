package com.brodowsky.admin.controller.user;

import com.brodowsky.admin.exceptions.UserNotFoundException;
import com.brodowsky.admin.security.UserDetails;
import com.brodowsky.admin.contract.user.IUserService;
import com.brodowsky.admin.utility.FileUploadUtil;
import com.brodowsky.common.entity.User;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.io.IOException;

@Controller
public class AccountController {

    private final IUserService service;

    public AccountController(IUserService service) {
        this.service = service;
    }

    @GetMapping("/Account")
    public String viewDetails(@AuthenticationPrincipal UserDetails loggedUser, Model model){
        String email = loggedUser.getUsername();
        User user = service.getByEmail(email);

        model.addAttribute("user", user);

        return "user/account_form";
    }

    @PostMapping("/Account/Update")
    public String saveDetails(User user, RedirectAttributes redirectAttributes, @AuthenticationPrincipal UserDetails loggedUser, @RequestParam("image") MultipartFile multipartFile) throws IOException, UserNotFoundException {
        if(!multipartFile.isEmpty()){
            String fileName = StringUtils.cleanPath(multipartFile.getOriginalFilename());
            user.setPhoto(fileName);
            User savedUser = service.updateUserAccount(user);

            String uploadDir = "user-images/" + savedUser.getId();

            FileUploadUtil.cleanDirectory(uploadDir);
            FileUploadUtil.saveFile(uploadDir, fileName, multipartFile);
        }else {

            if (user.getPhoto().isEmpty()) user.setPhoto(null);
            service.updateUserAccount(user);
        }

        loggedUser.setFirstName(user.getFirstName());
        loggedUser.setLastName(user.getLastName());

        redirectAttributes.addFlashAttribute("message", "Account has been updated.");
        //return "redirect:/Users/Page1?sortField=id&sortDir=asc&keyword=" + user.getEmail(); ASK FEEDBACK
        return "redirect:/Account";
    }

}
