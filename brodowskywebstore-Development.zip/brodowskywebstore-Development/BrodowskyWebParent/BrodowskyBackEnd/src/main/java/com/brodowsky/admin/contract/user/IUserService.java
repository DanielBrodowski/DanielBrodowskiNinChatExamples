package com.brodowsky.admin.contract.user;

import com.brodowsky.admin.exceptions.UserNotFoundException;
import com.brodowsky.common.entity.Role;
import com.brodowsky.common.entity.User;
import org.springframework.data.domain.Page;

import java.util.List;

public interface IUserService {

    User getByEmail(String email);
    List<User> listAll();
    Page<User> listByPage(int pageNum, String sortField, String sortDir, String keyword);
    List<Role> rolesList();
    User save(User user) throws UserNotFoundException;
    void encodePassword(User user);
    User updateUserAccount(User userAccount) throws UserNotFoundException;
    boolean isEmailUnique(Integer id, String email);
    User get(Integer id) throws UserNotFoundException;
    void deleteUser(int id) throws UserNotFoundException;

}
