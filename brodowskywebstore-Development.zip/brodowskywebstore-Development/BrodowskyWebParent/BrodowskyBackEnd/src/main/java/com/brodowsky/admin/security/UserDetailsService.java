package com.brodowsky.admin.security;

import com.brodowsky.admin.repository.user.UserRepository;
import com.brodowsky.common.entity.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

public class UserDetailsService implements org.springframework.security.core.userdetails.UserDetailsService {

    @Autowired
    private UserRepository userRepository;

    @Override
    public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
        User user = userRepository.getUserByEmail(email);

        if (user != null){
            return new com.brodowsky.admin.security.UserDetails(user);
        }

        throw new UsernameNotFoundException("User could not be found");
    }
}
