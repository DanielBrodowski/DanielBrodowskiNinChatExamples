package com.brodowsky.admin.service.brand;

import com.brodowsky.admin.constants.PageableConstants;
import com.brodowsky.admin.contract.brand.IBrandService;
import com.brodowsky.admin.exceptions.BrandNotFoundException;
import com.brodowsky.admin.repository.brand.BrandRepository;
import com.brodowsky.common.entity.Brand;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;

@Service
public class BrandService implements IBrandService {


    private final BrandRepository repo;

    public BrandService(BrandRepository repo) {
        this.repo = repo;
    }

    @Override
    public List<Brand> listAll() {
        return (List<Brand>) repo.findAll();
    }

    public Brand save(Brand brand) {
        return repo.save(brand);
    }

    public Brand get(Integer id) throws BrandNotFoundException {

        Optional<Brand> brand = repo.findById(id);
        if (brand.isEmpty()) {
            throw new BrandNotFoundException("Brand with id: " + id + " could not be found");
        }
        return brand.get();

    }

    public void delete(Integer id) throws BrandNotFoundException {
        Long countById = repo.countById(id);

        if (countById == null || countById == 0){
            throw new BrandNotFoundException("Brand with id: " + id + " could not be found");
        }

        repo.deleteById(id);
    }

    public Page<Brand> listByPage(int pageNum, String sortDir, String keyword) {
        Sort sort = Sort.by("name");

        if (sortDir.equals("asc")) {
            sort = sort.ascending();
        } else if (sortDir.equals("desc")){
            sort = sort.descending();
        }

        Pageable pageable = PageRequest.of(pageNum - 1, PageableConstants.brandsPerPage, sort);

        if (keyword != null) {
            return repo.findAll(keyword, pageable);
        }

        return repo.findAll(pageable);
    }


}
