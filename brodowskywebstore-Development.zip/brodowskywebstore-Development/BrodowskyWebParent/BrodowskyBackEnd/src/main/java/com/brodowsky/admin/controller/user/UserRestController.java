package com.brodowsky.admin.controller.user;

import com.brodowsky.admin.contract.user.IUserService;
import org.springframework.data.repository.query.Param;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class UserRestController {

    private final IUserService service;

    public UserRestController(IUserService service) {
        this.service = service;
    }

    @PostMapping("/Users/Email_check")
    public String checkDuplicateEmail(@Param("id") Integer id, @Param("email") String email){
        return service.isEmailUnique(id, email) ? "UNIQUE" : "DUPLICATE";

    }
}
