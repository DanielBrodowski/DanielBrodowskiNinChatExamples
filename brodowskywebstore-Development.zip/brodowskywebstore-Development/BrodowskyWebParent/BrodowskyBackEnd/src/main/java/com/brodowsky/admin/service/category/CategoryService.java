package com.brodowsky.admin.service.category;

import com.brodowsky.admin.constants.PageableConstants;
import com.brodowsky.admin.contract.category.ICategoryService;
import com.brodowsky.admin.exceptions.BrandNotFoundException;
import com.brodowsky.admin.exceptions.CategoryNotFoundException;
import com.brodowsky.admin.repository.category.CategoryRepository;
import com.brodowsky.common.entity.Brand;
import com.brodowsky.common.entity.Category;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class CategoryService implements ICategoryService {


    private final CategoryRepository repo;


    public CategoryService(CategoryRepository repo) {
        this.repo = repo;
    }

    public List<Category> listByPage(CategoryPageInfo pageInfo, int pageNum, String sortDir, String keyword){
        Sort sort = Sort.by("name");

        if (sortDir.equals("asc")) {
            sort = sort.ascending();
        } else if (sortDir.equals("desc")){
            sort = sort.descending();
        }

        Pageable pageable = PageRequest.of(pageNum - 1, PageableConstants.categoriesPerPage, sort);

        Page<Category> pageCategories = null;

        if (keyword != null && !keyword.isEmpty()){
            pageCategories = repo.search(keyword, pageable);
        } else {
            pageCategories = repo.rootCategoryList(pageable);
        }

        List<Category> rootCategories = pageCategories.getContent();

        pageInfo.setTotalElements(pageCategories.getTotalElements());
        pageInfo.setTotalPages(pageCategories.getTotalPages());

        if (keyword != null && !keyword.isEmpty()){
            List<Category> searchResult = pageCategories.getContent();
            for (Category category : searchResult){
                category.setHasChildren(category.getChildren().size() > 0);
            }

            return searchResult;

        } else {
            return listCategoryHierarchy(rootCategories);
        }
    }

    private List<Category> listCategoryHierarchy(List<Category> rootCategories){
        List<Category> categoryHierarchy = new ArrayList<>();

        for (Category rootCategory : rootCategories){
            categoryHierarchy.add(Category.copyCategory(rootCategory));

             Set<Category> children = sortSubCategories(rootCategory.getChildren());

             for (Category subCategory : children) {
                 String name = "•" + subCategory.getName();
                 categoryHierarchy.add(Category.copyCategory(subCategory, name));

                 listSubHierarchyCategories(categoryHierarchy, subCategory, 1);
             }
        }

        return categoryHierarchy;
    }

    private void listSubHierarchyCategories(List<Category> categoryHierarchy, Category parent, int subLevel){
        Set<Category> children = sortSubCategories(parent.getChildren());
        int newSubLevel = subLevel + 1;

        for (Category subCategory : children) {
            String name = "";
            for (int i = 0; i < newSubLevel; i++){
                name += "•";
            }
            name += subCategory.getName();

            categoryHierarchy.add(Category.copyCategory(subCategory, name));

            listSubHierarchyCategories(categoryHierarchy, subCategory, newSubLevel);
        }
    }

    @Override
    public List<Category> listCategoriesInForm() {
        List<Category> categoryListInForm = new ArrayList<>();

        Iterable<Category> categoryInDb = repo.rootCategoryList(Sort.by("name").ascending());

        for (Category category : categoryInDb){
            if (category.getParent() == null){
                categoryListInForm.add(Category.copyIdAndName(category));

                Set<Category> children = sortSubCategories(category.getChildren());

                for (Category subCategory : children){
                    String name = "•" + subCategory.getName();
                    categoryListInForm.add(Category.copyIdAndName(subCategory.getId(), name));

                    listChildren(categoryListInForm, subCategory, 1);
                }
            }
        }

        return categoryListInForm;
    }

    public Category save(Category category){
        return repo.save(category);
    }

    private void listChildren(List<Category> categoryListInForm, Category parent, int subLevel){
        int newSubLevel = subLevel + 1;
        Set<Category> children = sortSubCategories(parent.getChildren());

        for (Category subCategory : children){
            String name = "";
            for (int i = 0; i < newSubLevel; i++){
                name += "•";
            }

            name += subCategory.getName();
            categoryListInForm.add(Category.copyIdAndName(subCategory.getId(), name));

            listChildren(categoryListInForm, subCategory, newSubLevel);
        }
    }

    public Category get(Integer id) throws CategoryNotFoundException {

        Optional<Category> category = repo.findById(id);
        if (category.isEmpty()) {
            throw new CategoryNotFoundException("Category with id: " + id + " could not be found");
        }
        return category.get();
    }

    public void deleteCategory(Integer id) throws CategoryNotFoundException {
        Long countById = repo.countById(id);
        if (countById == null || countById == 0){
            throw new CategoryNotFoundException("Category with id: " + id + " could not be found");
        }

        repo.deleteById(id);
    }

    public SortedSet<Category> sortSubCategories(Set<Category> children){
        SortedSet<Category> sortedSubCategories = new TreeSet<>(new Comparator<Category>() {

            @Override
            public int compare(Category c1, Category c2) {
                return c1.getName().compareTo(c2.getName());
            }
        });

        sortedSubCategories.addAll(children);

        return sortedSubCategories;
    }

}
