package com.brodowsky.admin.contract.product;

import com.brodowsky.admin.exceptions.ProductNotFoundException;
import com.brodowsky.common.entity.Product;
import org.springframework.data.domain.Page;

import java.util.List;

public interface IProductService {

    List<Product> listAll();
    Product save(Product product);
    void delete(Integer id) throws ProductNotFoundException;
    Product get(Integer id) throws ProductNotFoundException;
    Page<Product> listByPage(int pageNum, String sortField, String sortDir, String keyword);

}
