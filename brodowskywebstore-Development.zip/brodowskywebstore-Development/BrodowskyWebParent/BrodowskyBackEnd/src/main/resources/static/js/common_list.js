function clearFilter(){
    window.location = moduleURL;
}

function showDeleteConfirmModal(link, entityName){
    entityId = link.attr("entityId");

        $("#okButton").attr("href", link.attr("href"));
        $("#confirmText").text("Are you sure you want to delete " + entityName + ": " + entityId + "?");
        $("#confirmModal").modal();
        //alert($(this).attr("href"));


    }

