package com.brodowsky.customer;

import com.brodowsky.common.entity.AuthenticationType;
import com.brodowsky.common.entity.Customer;
import com.brodowsky.site.BrodowskyFrontEndApplication;
import com.brodowsky.site.customer.CustomerRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;

import java.util.Date;

import static org.assertj.core.api.Assertions.assertThat;

@DataJpaTest
@ContextConfiguration(classes = BrodowskyFrontEndApplication.class)
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
@Rollback()
public class CustomerRepositoryTests {

    @Autowired private CustomerRepository repo;

    @Test
    public void testCreateCustomer(){
        Customer customer = new Customer();

        customer.setEmail("testingCustomer@test.com");
        customer.setPassword("password123");
        customer.setFirstName("Customer");
        customer.setLastName("Last Name");
        customer.setPhoneNumber("123456789");
        customer.setAddress("testStraat 20");
        customer.setCity("testCity");
        customer.setPostalCode("0000AB");
        customer.setCreatedTime(new Date());

        Customer savedCustomer = repo.save(customer);

        assertThat(savedCustomer).isNotNull();
        assertThat(savedCustomer.getId()).isGreaterThan(0);
    }

    @Test
    @Rollback(false)
    public void testUpdateAuthenticationType(){
        Integer id = 1;

        repo.updateAuthenticationType(id, AuthenticationType.GOOGLE);
        Customer customer = repo.findById(id).get();

        assertThat(customer.getAuthenticationType()).isEqualTo(AuthenticationType.GOOGLE);
    }

}
