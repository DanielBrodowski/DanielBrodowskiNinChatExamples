package com.brodowsky.site.customer;

import com.brodowsky.common.entity.AuthenticationType;
import com.brodowsky.common.entity.Customer;

import javax.mail.MessagingException;
import java.io.UnsupportedEncodingException;

public interface ICustomerService {

    boolean isEmailUnique(String email);
    Customer registerCustomer(Customer customer);
    void sendVerificationEmail(Customer customer, String siteURL) throws MessagingException, UnsupportedEncodingException;
    boolean verify(String verificationCode);
    void updateAuthenticationType(Customer customer, AuthenticationType type);
    Customer getCustomerByEmail(String email);
    void addNewOAuthCustomer(String name, String email, AuthenticationType authenticationType);
}
