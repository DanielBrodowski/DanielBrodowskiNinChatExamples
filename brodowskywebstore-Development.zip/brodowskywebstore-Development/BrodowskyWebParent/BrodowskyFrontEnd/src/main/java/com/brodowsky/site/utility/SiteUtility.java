package com.brodowsky.site.utility;

import javax.servlet.http.HttpServletRequest;

public class SiteUtility {
    public static String getSiteUrl(HttpServletRequest request){
        String siteURL = request.getRequestURL().toString();

        return siteURL.replace(request.getServletPath(), "");
    }
}
