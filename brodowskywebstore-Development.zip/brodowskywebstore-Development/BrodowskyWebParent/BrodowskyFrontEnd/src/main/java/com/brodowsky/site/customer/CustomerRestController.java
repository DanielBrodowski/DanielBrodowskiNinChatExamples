package com.brodowsky.site.customer;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.data.repository.query.Param;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class CustomerRestController {

    private final ICustomerService service;

    public CustomerRestController(@Lazy ICustomerService service) {
        this.service = service;
    }

    @PostMapping("/Customers/Email_check")
    public String checkDuplicateEmail(@Param("email") String email){
        return service.isEmailUnique(email) ? "UNIQUE" : "DUPLICATE";
    }
}
