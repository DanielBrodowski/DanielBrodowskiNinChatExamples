package com.brodowsky.site.security.Oauth;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.oauth2.core.user.OAuth2User;

import java.util.Collection;
import java.util.Map;

public class CustomerOAuth2User implements OAuth2User {

    private String clientName;
    private OAuth2User oauth2Useruser;

    public CustomerOAuth2User(OAuth2User user, String clientName) {
        this.oauth2Useruser = user;
        this.clientName = clientName;
    }

    @Override
    public Map<String, Object> getAttributes() {
        return oauth2Useruser.getAttributes();
    }

    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        return oauth2Useruser.getAuthorities();
    }

    @Override
    public String getName() {
        return oauth2Useruser.getAttribute("name");
    }

    public String getEmail(){
        return oauth2Useruser.getAttribute("email");
    }

    public String getClientName() {
        return clientName;
    }

    public String getFullName(){
        return oauth2Useruser.getAttribute("name");
    }
}
