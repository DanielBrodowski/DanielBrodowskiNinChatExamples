package com.brodowsky.site.customer;

import com.brodowsky.common.entity.Customer;
import com.brodowsky.site.utility.SiteUtility;
import org.dom4j.rule.Mode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import javax.mail.MessagingException;
import javax.servlet.http.HttpServletRequest;
import java.io.UnsupportedEncodingException;

@Controller
public class CustomerController {

    private final ICustomerService service;

    public CustomerController(ICustomerService service) {
        this.service = service;
    }

    @GetMapping("/Register")
    public String showRegisterForm(Model model){

        model.addAttribute("pageTitle", "New Customer");
        model.addAttribute("customer", new Customer());

        return "register/register_form";
    }

    @PostMapping("/New_Customer")
    public String createCustomer(Customer customer, Model model, HttpServletRequest request) throws MessagingException, UnsupportedEncodingException {
        service.registerCustomer(customer);

        String siteURL = SiteUtility.getSiteUrl(request);
        service.sendVerificationEmail(customer, siteURL);
        model.addAttribute("pageTitle", "Registration Successful.");

        return "register/register_success";
    }

    @GetMapping("/Verify")
    public String verifyAccount(@Param("code") String code, Model model){
        boolean verified = service.verify(code);

        String pageTitle = verified ? "Verification Successful" : "Verification Error";
        model.addAttribute("pageTitle", pageTitle);

        return "register/" + (verified ? "verify_success" : "verify_fail");
    }

}
