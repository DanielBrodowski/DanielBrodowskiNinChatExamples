package com.brodowsky.site.mail;

import java.sql.Clob;

public class mailTemplate {

    public String createMailTemplate(String name, String verifyURL){
        String mailContent =
                "<p>Dear" + name + ", </p>" +
                        "<p>Please click the link below to verify your registration:</p>" +
                        "<h3><a href=\"" + verifyURL + "\">VERIFY</a></h3>" +
                        "<p>Thank you,<br>The ShopByBrodowsky Team.</p>";

        return mailContent;
    }
}
