package com.brodowsky.site.customer;

import com.brodowsky.common.entity.AuthenticationType;
import com.brodowsky.common.entity.Customer;
import com.brodowsky.site.mail.mailTemplate;
import net.bytebuddy.utility.RandomString;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import javax.transaction.Transactional;
import java.io.UnsupportedEncodingException;
import java.util.Date;

@Service
public class CustomerService implements ICustomerService{

    private final JavaMailSender mailSender;
    final PasswordEncoder passwordEncoder;
    private final CustomerRepository repo;

    public CustomerService(CustomerRepository repo, PasswordEncoder passwordEncoder, JavaMailSender mailSender) {
        this.repo = repo;
        this.passwordEncoder = passwordEncoder;
        this.mailSender = mailSender;
    }


    public boolean isEmailUnique(String email) {
        Customer customer = repo.findByEmail(email);

        return customer == null;
    }

    public Customer registerCustomer(Customer customer) {
        encodePassword(customer);
        customer.setEnabled(false);
        customer.setCreatedTime(new Date());
        customer.setAuthenticationType(AuthenticationType.DATABASE);

        String verificationCode = RandomString.make(64);
        customer.setVerificationCode(verificationCode);

        return repo.save(customer);
    }

    public void sendVerificationEmail(Customer customer, String siteURL) throws MessagingException, UnsupportedEncodingException {
        String subject = "Account Verification";
        String sender = "ShopByBrodowski";
        String verifyURL = siteURL + "/Verify?code=" + customer.getVerificationCode();
        String mailContent = "<p>Dear " + customer.getFirstName() + ", </p>";
        mailContent += "<p>Please click the link below to verify your registration:</p>";

        mailContent += "<h3><a href=\"" + verifyURL + "\">VERIFY</a></h3>";

        mailContent += "<p>Thank you,<br>The ShopByBrodowsky Team.</p>";

        MimeMessage message = mailSender.createMimeMessage();
        MimeMessageHelper helper = new MimeMessageHelper(message);

        helper.setFrom("shopbybrodowsky@gmail.com", sender);
        helper.setTo(customer.getEmail());
        helper.setSubject(subject);
        helper.setText(mailContent, true);

        mailSender.send(message);

    }

    @Transactional
    public boolean verify(String verificationCode) {
        Customer customer = repo.findByVerificationCode(verificationCode);

        if (customer == null || customer.isEnabled()) {
            return false;
        } else {
            repo.enable(customer.getId());

            return true;
        }
    }

    @Override
    public void updateAuthenticationType(Customer customer, AuthenticationType type) {
        if (!customer.getAuthenticationType().equals(type)){
            repo.updateAuthenticationType(customer.getId(), type);
        }
    }

    @Override
    public Customer getCustomerByEmail(String email) {
        return repo.findByEmail(email);
    }

    private void encodePassword(Customer customer) {
        String encodedPassword = passwordEncoder.encode(customer.getPassword());
        customer.setPassword(encodedPassword);
    }

    public void addNewOAuthCustomer(String name, String email, AuthenticationType authenticationType) {
        Customer customer = new Customer();

        setNameOAuthUser(name, customer);
        customer.setEmail(email);
        customer.setEnabled(true);
        customer.setAuthenticationType(authenticationType);
        customer.setPassword("");
        customer.setPhoneNumber("");
        customer.setAddress("");
        customer.setCity("");
        customer.setPostalCode("");
        customer.setCreatedTime(new Date());

        repo.save(customer);
    }

    private void setNameOAuthUser(String name, Customer customer){
        String[] nameArray = name.split(" ");
        if (nameArray.length > 2){
            customer.setFirstName(name);
            customer.setLastName("");
        }else{
            String firstName = nameArray[0];
            customer.setFirstName(firstName);

            String lastName = name.replaceFirst(firstName + " ", "");
            customer.setLastName(lastName);
        }
    }

}
