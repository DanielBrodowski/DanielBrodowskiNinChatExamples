package com.brodowsky.common.entity;

public enum AuthenticationType {
    DATABASE, GOOGLE, FACEBOOK
}
