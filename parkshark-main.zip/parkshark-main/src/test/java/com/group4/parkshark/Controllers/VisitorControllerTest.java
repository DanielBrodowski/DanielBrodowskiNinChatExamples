package com.group4.parkshark.Controllers;

import com.group4.parkshark.Models.Visitor;
import com.group4.parkshark.Repositories.*;
import com.group4.parkshark.Services.AppointmentService;
import com.group4.parkshark.Services.VisitorService;
import com.group4.parkshark.SpringSecurityWebAuxTestConfig;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.security.test.context.support.WithUserDetails;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;

import static io.restassured.module.mockmvc.RestAssuredMockMvc.given;
import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.Matchers.*;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

@WebMvcTest(VisitorController.class)
@Import(SpringSecurityWebAuxTestConfig.class)
public class VisitorControllerTest {

    @MockBean private VisitorService visitorService;
    @MockBean private IVisitorRepository visitorRepository;
    @MockBean private IUserRepo userRepo;

    @MockBean private AppointmentService appointmentService;
    @MockBean private IAppointmentRepository appointmentRepository;
    @MockBean private JavaMailSender javaMailSender;

    @MockBean private IManagerRepository managerRepository;
    @MockBean private IParkingLotRepository parkingLotRepository;

    @Autowired private MockMvc mvc;

    private Visitor VISITOR;
    private Visitor OTHER_VISITOR;

    @Test void visitorServiceInitializedCorrectly() { assertThat(visitorService).isNotNull(); }
    @Test void visitorRepositoryInitializedCorrectly() { assertThat(visitorRepository).isNotNull(); }

    @BeforeEach
    void beforeEach() {
        VISITOR = Visitor.builder()
                .id(1L)
                .firstName("Aaron")
                .lastName("Sibusisiwe")
                .phone("412-515-7071")
                .email("Aaron@Sibusisiwe.com")
                .licensePlate("AARON")
                .build();
        OTHER_VISITOR = Visitor.builder()
                .id(2L)
                .firstName("Koloman")
                .lastName("Iriney")
                .phone("412-515-7072")
                .email("Koloman@Iriney.com")
                .licensePlate("KOLOMAN")
                .build();
    }

    @Test
    @WithUserDetails("matachanna")
    void shouldGetAllVisitorsSuccess() {

        when(visitorRepository.findAll()).thenReturn(List.of(VISITOR, OTHER_VISITOR));

        given().mockMvc(mvc)
                .get("/visitors")
                .then()
                .statusCode(200)
                .body("[0].id", equalTo(VISITOR.getId().intValue()))
                .body("[1].id", equalTo(OTHER_VISITOR.getId().intValue()));
    }

    @Test
    @WithUserDetails("pleb")
    void shouldGetAllVisitors403IfNotAdmin() {

        when(visitorRepository.findAll()).thenReturn(List.of(VISITOR, OTHER_VISITOR));

        given().mockMvc(mvc)
                .get("/visitors")
                .then()
                .statusCode(403);
    }

    @Test
    @WithUserDetails("matachanna")
    void shouldGetVisitorByIdSuccess() {

        when(visitorService.getVisitor(VISITOR.getId())).thenReturn(VISITOR);

        given().mockMvc(mvc)
                .get("/visitors/{id}", VISITOR.getId())
                .then()
                .statusCode(200)
                .body(is(notNullValue()));
    }

    @Test
    @WithUserDetails("pleb")
    void shouldGetVisitorById403IfNotAdmin() {

        when(visitorService.getVisitor(VISITOR.getId())).thenReturn(VISITOR);

        given().mockMvc(mvc)
                .get("/visitors/{id}", VISITOR.getId())
                .then()
                .statusCode(403);
    }

    @Test
    @WithUserDetails("matachanna")
    void shouldGetVisitorById404() {

        when(visitorService.getVisitor(99L)).thenReturn(null);

        given().mockMvc(mvc)
                .get("/visitors/{id}", 99L)
                .then()
                .statusCode(404);
    }

    @Test
    @WithUserDetails("matachanna")
    void shouldGetVisitorByEmailSuccess() {

        when(visitorService.getVisitorByEmail(VISITOR.getEmail())).thenReturn(VISITOR);

        given().mockMvc(mvc)
                .get("/visitors/email/{email}", VISITOR.getEmail())
                .then()
                .statusCode(200)
                .body(is(notNullValue()));
    }

    @Test
    @WithUserDetails("matachanna")
    void shouldGetVisitorByEmail200IfEmailNotFound() {

        when(visitorService.getVisitorByEmail("xyz@xyz.com")).thenReturn(null);

        given().mockMvc(mvc)
                .get("/visitors/email/{email}", "xyz@xyz.com")
                .then()
                .statusCode(200)
                .body(equalTo(""));
    }

    @Test
    @WithUserDetails("pleb")
    void shouldGetVisitorByEmail403IfNotAdmin() {

        when(visitorService.getVisitorByEmail(VISITOR.getEmail())).thenReturn(VISITOR);

        given().mockMvc(mvc)
                .get("/visitors/email/{email}", VISITOR.getEmail())
                .then()
                .statusCode(403);
    }

    @Test
    @WithUserDetails("matachanna")
    void shouldDeleteVisitorSuccess() {
        doNothing().when(visitorService).deleteVisitor(VISITOR.getId());

        given().mockMvc(mvc)
                .delete("/visitors/delete/{id}", VISITOR.getId())
                .then()
                .statusCode(200);

    }

    @Test
    @WithUserDetails("pleb")
    void shouldDeleteVisitor403IfNotAdmin() {
        doNothing().when(visitorService).deleteVisitor(VISITOR.getId());

        given().mockMvc(mvc)
                .delete("/visitors/delete/{id}", VISITOR.getId())
                .then()
                .statusCode(403);
    }
}
