package com.group4.parkshark.Controllers;

import com.group4.parkshark.Controllers.UserController;
import com.group4.parkshark.DTOs.UserDTO;
import com.group4.parkshark.Models.User;
import com.group4.parkshark.Services.UserService;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.ResponseEntity;

import java.util.ArrayList;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.doNothing;

@ExtendWith(MockitoExtension.class)
public class UserController_Test {

    @InjectMocks
    private UserController userController;
    @Mock
    private UserService userService;

    @Test
    void getAllUsers(){
        // Arrange
        ResponseEntity<List<User>> users;
        List<User> mockUsers = new ArrayList<>();
        User mockUser1 = new User();
        mockUsers.add(mockUser1);
        User mockUser2 = new User();
//        mockUser1.setId(2L);
//        mockUser1.setName("test123");
//        mockUser1.setEmail("test123@test.test");
//        mockUser1.setPassword("test123");
//        mockUser1.setRole("ADMIN");
        mockUsers.add(mockUser2);
        // Act
        Mockito.when(userService.getAllUsers()).thenReturn(mockUsers);
        users = userController.getAllUsers();
        // Assert
        Assertions.assertEquals(mockUsers.size(), users.getBody().size());
    }

    @Test
    void getUserPath(){
        // Arrange
        ResponseEntity<User> user;
        long id = 1;
        User _user = new User();
        _user.setId(id);
        // Act
        Mockito.when(userService.getUser(anyLong())).thenReturn(_user);
        user = userController.getUserPath(id);
        // Assert
        Assertions.assertEquals(_user.getId(), user.getBody().getId());
    }

    @Test
    void addNewUser(){
        // Arrange
        User user = new User();
        User newUser = new User();
        User retreivedUser;
        // Act
        Mockito.when(userService.createUser(any(User.class))).thenReturn(user);
        retreivedUser = userController.addNewUser(newUser);
        // Assert
        Assertions.assertEquals(retreivedUser, user);
    }

    @Test
    void deleteUser(){
        // Arrange
        long id = 1;
        // Act
        userController.deleteUser(id);
        // Assert
        Assertions.assertEquals(id, id);
    }

    @Test
    void updateUser(){
        // Arrange
        User updatedUser = new User();
        Boolean updated;
        // Act
        Mockito.when(userService.updateUser(any(User.class))).thenReturn(true);
        updated = userService.updateUser(updatedUser);
        // Assert
        Assertions.assertTrue(updated);
    }
}
