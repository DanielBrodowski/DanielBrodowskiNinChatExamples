package com.group4.parkshark;

import com.group4.parkshark.Models.User;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Primary;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;

import java.util.Arrays;
import java.util.List;

@TestConfiguration
public class SpringSecurityWebAuxTestConfig {

    @Bean
    @Primary
    public UserDetailsService userDetailsServiceTest() {
        CustomUser admin = new CustomUser(1L, "matachanna", "matachanna@matachanna.com", "password123", "ADMIN");
        CustomUser pleb = new CustomUser(2L, "pleb", "pleb@pleb.com", "password234", "PLEB");
        return new InMemoryUserDetailsManager(Arrays.asList(admin, pleb));
    }
}
