package com.group4.parkshark.Controllers;

import com.group4.parkshark.Models.Manager;
import com.group4.parkshark.Repositories.IManagerRepository;
import com.group4.parkshark.Services.ManagerService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.ResponseEntity;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;

@ExtendWith(MockitoExtension.class)
class ManagerControllerTest {

    @Mock
    ManagerService managerServiceMock;
    @InjectMocks
    ManagerController managerController;

    //assign
    //act
    //assert


    @Test
    void getAllManagers() {
        List<Manager> managers = new ArrayList<>();
        ResponseEntity<List<Manager>> retrievedList;
        Manager manager1 = new Manager();
        Manager manager2 = new Manager();
        //act
        managers.add(manager1);
        managers.add(manager2);
        Mockito.when(managerServiceMock.getAllManagers()).thenReturn(managers);
        retrievedList = managerController.getAllManagers();
        //assert
        assertTrue (retrievedList.getBody().size() >0);
    }

    @Test
    void getManagerById() {
        //assign
        long id = 999;
        Manager manager = new Manager();
        manager.setId(id);
        manager.setEmail("mockitomaile@mock.com");
        manager.setFirst_name("Mock");
        manager.setLast_name("Ito");
        ResponseEntity<Manager> foundManager;
        //act
        Mockito.when(managerServiceMock.getManager(anyLong())).thenReturn(manager);
        foundManager = managerController.getManagerById(id);
        //assert
        assertTrue(manager.id == foundManager.getBody().id );
    }

    @Test
    void createManager() {
        long id = 999;
        Manager manager = new Manager();
        manager.setId(id);
        manager.setEmail("mockitomaile@mock.com");
        manager.setFirst_name("Mock");
        manager.setLast_name("Ito");
        Manager createdManager;
        //act
        Mockito.when(managerServiceMock.createManager(any(Manager.class))).thenReturn(manager);
        createdManager = managerController.createManager(manager);
        //assert
        assertTrue(manager.first_name == createdManager.first_name );
    }

    @Test
    void updateManager() {
        //assign
        long id = 999;
        boolean updated;
        Manager managerMock = new Manager();
        //act
        Mockito.when(managerServiceMock.updateManager(any(Manager.class))).thenReturn(true);
        updated = managerServiceMock.updateManager(managerMock);
        //assert
        assertTrue(updated);

    }

    @Test
    void deleteAppointment() {
        //assign
        long id = 1;
        List<Manager> managers = new ArrayList<>();
        List<Manager> deletedlist = new ArrayList<>();
        Manager manager1 = new Manager();
        manager1.setId(id);
        Manager manager2 = new Manager();
        Manager manager3 = new Manager();
        //act
        managers.add(manager1);
        managers.add(manager2);
        managers.add(manager3);
        deletedlist.add(manager1);
        deletedlist.add(manager2);
        //assert
        assertFalse(managers.size() == deletedlist.size());
    }
}