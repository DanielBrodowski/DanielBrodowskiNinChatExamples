package com.group4.parkshark;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ParkSharkApplicationTests {

    @Test
    void contextLoads() {
    }

}
