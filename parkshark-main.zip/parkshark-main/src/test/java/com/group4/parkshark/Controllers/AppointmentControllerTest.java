package com.group4.parkshark.Controllers;

import com.group4.parkshark.Models.Appointment;
import com.group4.parkshark.Services.AppointmentService;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.ResponseEntity;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class AppointmentControllerTest {
    @Mock
    private AppointmentService appServiceMock;
    @InjectMocks
    private AppointmentController appController;

    //assign
    //act
    //assert

    @Test
    void getAllAppointments() {
        List<Appointment> mockApps = new ArrayList<>();
        ResponseEntity<List<Appointment>> retrievedList;
        Appointment app1 = new Appointment();
        Appointment app2 = new Appointment();
        //act
        mockApps.add(app1);
        mockApps.add(app2);
        Mockito.when(appServiceMock.getAllAppointments()).thenReturn(mockApps);
        retrievedList = appController.getAllAppointments();
        //assert
        Assertions.assertEquals(mockApps.size(), retrievedList.getBody().size());
    }

    @Test
    void getAppointmentById() {

        //assign
        long id = 1;
        ResponseEntity<Appointment> foundAppointment;
        Appointment app = new Appointment();
        app.setId(id);

        //act
        Mockito.when(appServiceMock.getAppointment(anyLong())).thenReturn(app);
        foundAppointment = appController.getAppointmentPath(id);
        //assert
        Assertions.assertEquals(app.getId(), foundAppointment.getBody().getId());
    }

    @Test
    void createAppointment() {
        Appointment app = new Appointment();
        Appointment newApp = new Appointment();

        Appointment createdAppointment;
        //act
        Mockito.when(appServiceMock.createAppointment(any(Appointment.class))).thenReturn(app);
        createdAppointment = appController.addNewAppointment(newApp);
        //assert
        Assertions.assertEquals(createdAppointment, app);
    }

    @Test
    void updateAppointment() {
        long id = 999;
        boolean updated;
        Appointment appMock = new Appointment();
        //act
        Mockito.when(appServiceMock.updateAppointment(any(Appointment.class))).thenReturn(true);
        updated = appServiceMock.updateAppointment(appMock);
        //assert
        assertTrue(updated);
    }

    @Test
    void deleteAppointment() {
        //assign
        long id = 1;
        List<Appointment> apps = new ArrayList<>();
        List<Appointment> deletedlist = new ArrayList<>();
        Appointment app1 = new Appointment();
        app1.setId(id);
        Appointment app2 = new Appointment();
        Appointment app3 = new Appointment();
        //act
        apps.add(app1);
        apps.add(app2);
        apps.add(app3);
        deletedlist.add(app1);
        deletedlist.add(app2);
        //assert
        assertFalse(apps.size() == deletedlist.size());
    }
}
