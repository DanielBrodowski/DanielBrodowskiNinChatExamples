package com.group4.parkshark.Controllers;

import com.group4.parkshark.DTOs.ParkingSpotDTO;
import com.group4.parkshark.DTOs.VisitorDTO;
import com.group4.parkshark.Models.Appointment;
import com.group4.parkshark.Services.*;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.mail.MessagingException;
import java.io.UnsupportedEncodingException;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/sensor")
@RequiredArgsConstructor
public class IOTController {


    //services
    private final MailService mailService;
    private final AppointmentService appointmentService;
    private final VisitorService visitorService;
    private final ParkingLotService parkingLotService;
    private final SmsService smsService;

    Logger logger = LoggerFactory.getLogger(IOTController.class);
    @PostMapping("/park")
    public void detectParkingSpot(@RequestBody ParkingSpotDTO parkingSpotDTO) {
        logger.debug("Parking spot " + parkingSpotDTO.getSpotNumber());
        System.out.println("Parking spot " + parkingSpotDTO.getSpotNumber());
        //set the recieved spot as occupied in the database
        parkingLotService.setAsOccupied(parkingSpotDTO);
        boolean parkinlotFull = checkParkingLotStatus();
        if(parkinlotFull == true){
            smsService.sendNotificationSms("+31616343007");
        }

    }
    @PostMapping("/license/{lp}")
    public void detectLicensePlate(@PathVariable(value = "lp") String lp) throws MessagingException, UnsupportedEncodingException {
        System.out.println("Lp  " + lp);
        VisitorDTO visitorDTO = visitorService.getVisitorByLicensePlate(lp);
        Appointment appointment = appointmentService.findAppointmentByVisitorId(visitorDTO.getId());
        smsService.sendNotificationSms("+31616343007");
        //mailService.sendConfirmationEmail(appointment);
    }
    @GetMapping("/status")
    public ResponseEntity<List<ParkingSpotDTO>> getParkingLotStatus(){
        List<ParkingSpotDTO> parkingSpotDTOS = parkingLotService.getAllSpots();
        return ResponseEntity.ok().body(parkingSpotDTOS);
    }


    //Checks if the parkinglot is almost full. max space = 20
    //use this method to send the corresponding sms = "there is space" or "suggest this location:"
    private boolean checkParkingLotStatus(){
        boolean almostFull = false;
        int occupiesSpots = 0;
        List<ParkingSpotDTO> parkingSpotDTOList = parkingLotService.getAllSpots();
        for (ParkingSpotDTO parkingSpotDTO:parkingSpotDTOList)
        {
            if(parkingSpotDTO.isOccupied()){
                occupiesSpots ++;
            }
        }
        if(occupiesSpots >= 18){
            almostFull = true;
        }
        return almostFull;
    }
}
