package com.group4.parkshark.Controllers;

import com.group4.parkshark.Models.Appointment;
import com.group4.parkshark.Repositories.IAppointmentRepository;
import com.group4.parkshark.Services.AppointmentService;
import com.group4.parkshark.Services.MailService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.mail.MessagingException;
import java.io.UnsupportedEncodingException;
import java.util.List;

@CrossOrigin(origins = "http://localhost:3000", allowedHeaders = "*")
@RestController
@RequiredArgsConstructor

public class AppointmentController {


    private final AppointmentService service;
    private final IAppointmentRepository appointmentRepository;
    //These appointment Models need to be replaced with Their DTO version later
    @Autowired
    private MailService mailService;

    @GetMapping("/appointments")
    public ResponseEntity<List<Appointment>> getAllAppointments() {
        List<Appointment> appointments = service.getAllAppointments();
        return ResponseEntity.ok().body(appointments);
    }

    @GetMapping("/appointments/{id}")
    public ResponseEntity<Appointment> getAppointmentPath(@PathVariable(value = "id") Long id) {
        Appointment appointment = service.getAppointment(id);
        if (appointment != null) {
            return ResponseEntity.ok().body(appointment);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @PostMapping("/appointments/save")
    public Appointment addNewAppointment(@RequestBody Appointment appointment) {
        //mailService.sendConfirmationEmail(appointment);
        return service.createAppointment(appointment);
    }

    @DeleteMapping("/appointments/{id}")
    public ResponseEntity deleteAppointment(@PathVariable Long id) {
        service.deleteAppointment(id);
        return ResponseEntity.ok().build();
    }

    @PutMapping("/appointments/update/{id}")
    public ResponseEntity<Appointment> updateAppointment(@RequestBody Appointment appointment) {
        if (service.updateAppointment(appointment)) {
            return ResponseEntity.noContent().build();
        } else {
            return ResponseEntity.ok().build();
        }
    }

}
