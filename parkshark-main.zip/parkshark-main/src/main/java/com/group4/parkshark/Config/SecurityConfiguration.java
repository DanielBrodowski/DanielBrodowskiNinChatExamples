package com.group4.parkshark.Config;

import com.group4.parkshark.Filters.JWTAuthenticationFilter;
import com.group4.parkshark.Filters.JWTAuthorizationFilter;
import com.group4.parkshark.Services.AuthenticationUserDetailService;

import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import lombok.RequiredArgsConstructor;

@EnableWebSecurity
@RequiredArgsConstructor
public class SecurityConfiguration extends WebSecurityConfigurerAdapter {

    private final BCryptPasswordEncoder bCryptPasswordEncoder;
    private final AuthenticationUserDetailService authenticationUserDetailService;

    @Override
    protected void configure(HttpSecurity http) throws Exception
    {
        http.cors().and().csrf().disable().authorizeRequests()
                //ROLE BASED AUTHENTICATION START
                .antMatchers(HttpMethod.POST, "/login").permitAll()
                .antMatchers(HttpMethod.GET, "/user/getallusers").permitAll()
                .antMatchers(HttpMethod.GET, "/user/**").hasAnyAuthority("ADMIN")
                .antMatchers(HttpMethod.POST, "/user/save").permitAll()
                .antMatchers(HttpMethod.POST, "/sensor/license/**").permitAll()
                .antMatchers(HttpMethod.POST, "/sensor/license").permitAll()
                .antMatchers(HttpMethod.POST, "/sensor/park").permitAll()
                .antMatchers(HttpMethod.GET, "/sensor/status").permitAll()
                .antMatchers(HttpMethod.DELETE, "/user/**").hasAnyAuthority("ADMIN")
                .antMatchers(HttpMethod.PUT, "/user/update").hasAnyAuthority("ADMIN")
                .antMatchers(HttpMethod.GET, "/visitors").hasAnyAuthority("ADMIN")
                .antMatchers(HttpMethod.GET, "/visitors/**").hasAnyAuthority("ADMIN")
                .antMatchers(HttpMethod.POST, "/visitors/create").hasAnyAuthority("ADMIN")
                .antMatchers(HttpMethod.PUT, "/visitors/update").hasAnyAuthority("ADMIN")
                .antMatchers(HttpMethod.DELETE, "/visitors/delete/**").hasAnyAuthority("ADMIN")
                .antMatchers(HttpMethod.GET, "/managers").hasAnyAuthority("ADMIN")
                .antMatchers(HttpMethod.GET, "/managers/**").hasAnyAuthority("ADMIN")
                .antMatchers(HttpMethod.POST, "/managers/create").hasAnyAuthority("ADMIN")
                .antMatchers(HttpMethod.PUT, "/managers/update").hasAnyAuthority("ADMIN")
                .antMatchers(HttpMethod.DELETE, "/managers/delete").hasAnyAuthority("ADMIN")
                //.antMatchers("/hello").permitAll()
                .antMatchers(HttpMethod.GET, "/appointments").hasAnyAuthority("ADMIN")
                .antMatchers(HttpMethod.GET, "/appointments/**").hasAnyAuthority("ADMIN")
                .antMatchers(HttpMethod.POST, "/appointments/save").hasAnyAuthority("ADMIN")
                .antMatchers(HttpMethod.DELETE, "/appointments/delete/**").hasAnyAuthority("ADMIN")
                .antMatchers(HttpMethod.PUT, "/appointments/update/**").hasAnyAuthority("ADMIN")
                //ROLE BASED AUTHENTICATION END
                .anyRequest().authenticated()
                .and()
                .addFilter(new JWTAuthenticationFilter(authenticationManager()))
                .addFilter(new JWTAuthorizationFilter(authenticationManager()))
                // this disables session creation on Spring Security
                .sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS);
    }

    @Override
    public void configure(AuthenticationManagerBuilder auth) throws Exception {
        auth.userDetailsService(authenticationUserDetailService).passwordEncoder(bCryptPasswordEncoder);
    }
}
