package com.group4.parkshark.Repositories;
import com.group4.parkshark.Models.Visitor;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface IVisitorRepository extends  JpaRepository<Visitor, Long> {
    Optional<Visitor> findByEmail(String email);
    Optional<Visitor> findByLicensePlate(String licensePlate);
}
