package com.group4.parkshark.Services;

import com.group4.parkshark.Models.Appointment;
import com.group4.parkshark.Repositories.IAppointmentRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import javax.persistence.EntityNotFoundException;
import java.util.List;

@Service
@RequiredArgsConstructor
public class AppointmentService {
    private final IAppointmentRepository repo;

    public List<Appointment> getAllAppointments() {
        return repo.findAll();
    }

    public Appointment getAppointment(Long id) {
        return repo.findById(id).orElse(null);
    }

    public Appointment createAppointment(Appointment appointment) {
        return repo.save(appointment);
    }

    public void deleteAppointment(Long id) {
        repo.deleteById(id);
    }

    public Appointment findAppointmentByVisitorId(Long visitorId) throws EntityNotFoundException {
        return repo.findByVisitorId(visitorId).orElse(null);
    }


    public boolean updateAppointment(Appointment updAppointment) {
        Appointment appointment = repo.findById(updAppointment.getId()).orElse(null);
        if (appointment != null) {
            repo.save((updAppointment));
            return true;
        } else {
            return false;
        }
    }
}
