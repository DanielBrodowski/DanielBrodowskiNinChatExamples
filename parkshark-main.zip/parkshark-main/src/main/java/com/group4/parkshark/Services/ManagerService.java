package com.group4.parkshark.Services;

import com.group4.parkshark.Models.Appointment;
import com.group4.parkshark.Models.Manager;
import com.group4.parkshark.Repositories.IManagerRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class ManagerService {
    private final IManagerRepository repo;

    public List<Manager> getAllManagers() {
        return repo.findAll();
    }

    public Manager getManager(Long id) {
        return repo.findById(id).orElse(null);
    }

    public Manager createManager(Manager manager) {
        return repo.save(manager);
    }

    public void deleteManager(Long id) {
        repo.deleteById(id);
    }

    public boolean updateManager(Manager updManager) {
        Manager manager = repo.findById(updManager.getId()).orElse(null);
        if (manager != null) {
            repo.save((updManager));
            return true;
        } else {
            return false;
        }
    }
}
