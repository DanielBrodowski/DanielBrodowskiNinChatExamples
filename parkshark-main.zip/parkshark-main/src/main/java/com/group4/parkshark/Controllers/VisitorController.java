package com.group4.parkshark.Controllers;

import com.group4.parkshark.DTOs.AppointmentDTO;
import com.group4.parkshark.Models.Appointment;
import com.group4.parkshark.Models.Manager;
import com.group4.parkshark.Models.Visitor;
import com.group4.parkshark.Repositories.IAppointmentRepository;
import com.group4.parkshark.Repositories.IManagerRepository;
import com.group4.parkshark.Repositories.IVisitorRepository;
import com.group4.parkshark.Services.AppointmentService;
import com.group4.parkshark.Services.ManagerService;
import com.group4.parkshark.Services.VisitorService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins = "http://localhost:3000", allowedHeaders = "*")
@RestController
@RequiredArgsConstructor
public class VisitorController
{
    private final VisitorService service;
    private final IVisitorRepository visitorRepository;

    @GetMapping("/visitors")
        public ResponseEntity<List<Visitor>> getAllVisitors()
    {
        List<Visitor> visitors = visitorRepository.findAll();
        return ResponseEntity.ok().body(visitors);
    }
    @GetMapping("/visitors/{id}")
    public ResponseEntity<Visitor> getVisitorById(@PathVariable(value = "id") Long id){
        Visitor visitor = service.getVisitor(id);
        if(visitor != null){
            return ResponseEntity.ok().body(visitor);
        }
        else{
            return ResponseEntity.notFound().build();
        }
    }

    @GetMapping("/visitors/email/{email}")
    public Visitor getVisitorByEmail(@PathVariable(value = "email") String email){
        Visitor visitor = service.getVisitorByEmail(email);
        if(visitor != null){
            return visitor;
        }
        else{
            return null;
        }
    }
    @PostMapping("/visitors/create")
    public Visitor createVisitor(@RequestBody Visitor visitor)
    {
        return service.createVisitor(visitor);
    }

    @DeleteMapping("/visitors/delete/{id}")
    public ResponseEntity<String> deleteVisitor(@PathVariable(value = "id") Long id)
    {
        service.deleteVisitor(id);
        return ResponseEntity.ok("Visitor successfully updated");
    }
}
