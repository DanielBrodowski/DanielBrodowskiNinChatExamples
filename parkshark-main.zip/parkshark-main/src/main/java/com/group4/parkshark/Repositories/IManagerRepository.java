package com.group4.parkshark.Repositories;

import com.group4.parkshark.Models.Manager;
import org.springframework.data.jpa.repository.JpaRepository;

public interface IManagerRepository extends JpaRepository<Manager, Long> {
}
