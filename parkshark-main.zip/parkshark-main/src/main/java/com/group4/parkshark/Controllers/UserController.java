package com.group4.parkshark.Controllers;

import com.group4.parkshark.DTOs.UserDTO;
import com.group4.parkshark.Models.User;
import com.group4.parkshark.Services.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins = "http://localhost:3000", allowedHeaders = "*")
@RestController
@RequiredArgsConstructor
public class UserController {

    private final UserService service;

    @PostMapping("/login")
    public ResponseEntity<?> getToken(@RequestBody UserDTO userDTO) {
        return ResponseEntity.ok().build();
    }

    @GetMapping("/user/getallusers")
    public ResponseEntity<List<User>> getAllUsers(){
        List<User> userList = service.getAllUsers();
        return ResponseEntity.ok().body(userList);
    }

    @GetMapping("/user/{id}")
    public ResponseEntity<User> getUserPath(@PathVariable(value = "id") Long id){
        User user = service.getUser(id);
        if(user != null){
            return ResponseEntity.ok().body(user);
        }
        else{
            return ResponseEntity.notFound().build();
        }
    }
    @PostMapping("/user/save")
    public User addNewUser(@RequestBody User user){
        return service.createUser(user);
    }
    @DeleteMapping("/user/{id}")
    public ResponseEntity deleteUser(@PathVariable Long id){
        service.deleteUser(id);
        return ResponseEntity.ok().build();
    }
    @PutMapping("/user/update")
    public ResponseEntity<User> updateUser(@RequestBody User user){
        if(service.updateUser(user)){
            return ResponseEntity.noContent().build();
        }
        else{
            return ResponseEntity.ok().build();
        }
    }
}
