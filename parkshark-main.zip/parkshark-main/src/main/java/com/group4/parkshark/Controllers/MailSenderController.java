package com.group4.parkshark.Controllers;


import com.group4.parkshark.Services.MailService;
import com.group4.parkshark.Services.SmsService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.mail.MessagingException;
import java.io.UnsupportedEncodingException;

@CrossOrigin(origins = "http://localhost:3000", allowedHeaders = "*")
@RestController
@RequiredArgsConstructor
public class MailSenderController {

    private MailService mailService;
    private SmsService smsService;

    @Autowired
    public MailSenderController(MailService mailService, SmsService smsService) {
        this.mailService = mailService;
        this.smsService = smsService;
    }

    @RequestMapping({"/mail/send"})
    public String sendConfirmationEmail() throws MessagingException, UnsupportedEncodingException {
        //mailService.sendConfirmationEmail();

        return "Please check your email";
    }

    @GetMapping({"/sms/send"})
    public String sendConfirmationSms() {
        smsService.sendNotificationSms("+31616343007");
        return "Please check your messages";
    }

}
