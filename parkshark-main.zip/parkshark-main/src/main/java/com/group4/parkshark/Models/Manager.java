package com.group4.parkshark.Models;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name= "managers")
@Getter
@Setter
@NoArgsConstructor
public class Manager
{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Long id;

    @Column(name = "created_at", nullable = true)
    public Date created_at;

    @Column(name = "updated_at", nullable = true)
    public Date updated_at;

    @Column(name = "first_name", nullable = false)
    public String first_name;

    @Column(name = "prefix", nullable = true)
    public String prefix;

    @Column(name = "last_name", nullable = false)
    public String last_name;

    @Column(name = "email", nullable = false)
    public String email;

    public Manager(String first_name, String prefix, String last_name, String email)
    {
        this.first_name = first_name;
        this.prefix = prefix;
        this.last_name = last_name;
        this.email = email;
    }
}
