package com.group4.parkshark.Models;

import lombok.*;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name= "visitors")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor(access = AccessLevel.PRIVATE) //Hides the constructor to force usage of the Builder
@Builder
public class Visitor
{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Long id;

    @Column(name = "created_at", nullable = true)
    public Date createdAt;

    @Column(name = "updated_at", nullable = true)
    public Date updatedAt;

        @Column(name = "first_name", nullable = true)
    public String firstName;

    @Column(name = "prefix", nullable = true)
    public String prefix;

    @Column(name = "phone", nullable = false)
    public String phone;

    @Column(name = "last_name", nullable = false)
    public String lastName;

    @Column(name = "email", nullable = false)
    public String email;

    @Column(name = "licenseplate", nullable = false)
    public String licensePlate;
}
