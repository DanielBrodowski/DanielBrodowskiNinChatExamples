package com.group4.parkshark.Services;

import com.group4.parkshark.DTOs.ParkingSpotDTO;
import com.twilio.Twilio;
import com.twilio.rest.api.v2010.account.Message;
import com.twilio.rest.lookups.v1.PhoneNumber;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import javax.naming.AuthenticationException;
import java.util.ArrayList;
import java.util.List;

@Service
@RequiredArgsConstructor
public class SmsService {

    public static final String ACCOUNT_SID = "AC48270644987753e3ac28cd4cca71b685";
    public static final String AUTH_TOKEN = "b37456783873d834ec4a7aa5b1c3a5d9";

    private final ParkingLotService parkingLotService;


    public void sendNotificationSms(String visitorPhoneNr){
        Twilio.init(ACCOUNT_SID, AUTH_TOKEN);
            Message message = Message.creator(
                            new com.twilio.type.PhoneNumber(visitorPhoneNr),
                            new com.twilio.type.PhoneNumber("+3197010255895"),
                            "Dear visitor, currently all our parking spaces are filled. \n" +
                                    "\nPlease consider parking at the following location: \n \nhttps://goo.gl/maps/vgJ1bqyV1C312Y8s6." +
                                    "\n\n\nParkShark.")
                    .create();

            System.out.println(message.getSid());
    }
}
