package com.group4.parkshark.DTOs;

import lombok.Data;

import java.util.Date;

@Data
public class ManagerDTO
{
    private Long id;
    private Date created_at;
    private Date updated_at;
    private String first_name;
    private String prefix;
    private String last_name;
    private String email;
}
