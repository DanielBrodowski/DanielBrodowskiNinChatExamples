package com.group4.parkshark.DTOs;

import lombok.Data;

import javax.persistence.Column;
import java.util.Date;

@Data
public class AppointmentDTO {
    private Long id;
    private Long manager_id;
    private Long visitor_id;
    private Long user_id;
    private Date starts_at;
    private Date ends_at;
    private Date created_at;
    private Date updated_at;
}
