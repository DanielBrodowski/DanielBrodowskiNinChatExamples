package com.group4.parkshark.Services;

import com.group4.parkshark.Models.Appointment;
import com.group4.parkshark.Models.Manager;
import com.group4.parkshark.Models.Visitor;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import java.io.UnsupportedEncodingException;

@Service
public class MailService {

    private final JavaMailSender mailSender;
    private final ManagerService managerService;
    private final VisitorService visitorService;

    public MailService(JavaMailSender mailSender, ManagerService service, VisitorService visitorService) {
        this.mailSender = mailSender;
        this.managerService = service;
        this.visitorService = visitorService;
    }

    //give Customer and Manager entities to method
    public void sendConfirmationEmail(Appointment appointment) throws MessagingException, UnsupportedEncodingException {

        Manager manager = managerService.getManager(appointment.getManagerId());
        Visitor visitor = visitorService.getVisitor(appointment.getVisitorId());

        String subject = "Appointment Confirmation";
        String sender = "ParkShark";
        //Need to retrieve manager name from repo
        String mailContent = "<p>Dear " + manager.first_name + ", </p>";
        mailContent += "<p>Hereby we would like to inform you that visitor:</p>";

        //Retrieve Visitor name from repo
        mailContent += "<h2>" + visitor.firstName + " " + visitor.lastName + "</h2>";
        mailContent += "will be arriving shortly.";

        mailContent += "<p>With kind regards,<br>The ParkShark Team.</p>";

        MimeMessage message = mailSender.createMimeMessage();
        MimeMessageHelper helper = new MimeMessageHelper(message);

        helper.setFrom("shopbybrodowsky@gmail.com", sender);
        //Retrieve Visitor email after testing is done
        helper.setTo(manager.getEmail());
        //helper.setTo("shopbybrodowsky@gmail.com");
        helper.setSubject(subject);
        helper.setText(mailContent, true);

        mailSender.send(message);
    }

}
