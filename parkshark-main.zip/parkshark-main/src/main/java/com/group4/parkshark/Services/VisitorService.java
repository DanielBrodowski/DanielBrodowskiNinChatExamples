package com.group4.parkshark.Services;

import com.group4.parkshark.DTOs.VisitorDTO;
import com.group4.parkshark.Models.Visitor;
import com.group4.parkshark.Repositories.IVisitorRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import javax.persistence.EntityNotFoundException;
import java.util.List;

@Service
@RequiredArgsConstructor
public class VisitorService
{
    private final IVisitorRepository repo;

    public List<Visitor> getAllVisitor()
    {
        return repo.findAll();
    }

    public Visitor getVisitor(Long id){
        return repo.findById(id).orElse(null);
    }

    public Visitor getVisitorByEmail(String email){
        return repo.findByEmail(email).orElse(null);
    }

    public VisitorDTO getVisitorByLicensePlate(String licensePlate){
        Visitor visitor = repo.findByLicensePlate(licensePlate).orElse(null);
        if(visitor != null){
            return createVisitorDTOFromModel(visitor);
        }
        else{
            throw new EntityNotFoundException();
        }
    }

    public Visitor createVisitor (Visitor visitor){
        return repo.save(visitor);
    }
    public void deleteVisitor (Long id){
        repo.deleteById(id);
    }
    public boolean updateVisitor(Visitor updVisitor){
        Visitor visitor = repo.findById(updVisitor.getId()).orElse(null);
        if(visitor != null){
            repo.save((updVisitor));
            return true;
        }
        else{
            return false;
        }
    }

    private VisitorDTO createVisitorDTOFromModel(Visitor visitor){

        VisitorDTO visitorDTO = new VisitorDTO();

        //set dto values from the model
        visitorDTO.setId(visitor.getId());
        visitorDTO.setEmail(visitor.getEmail());
        visitorDTO.setFirst_name(visitor.getFirstName());
        visitorDTO.setLast_name(visitor.getLastName());
        visitorDTO.setCreated_at(visitor.getCreatedAt());
        visitorDTO.setUpdated_at(visitor.getUpdatedAt());
        visitorDTO.setPhone(visitor.getPhone());
        visitorDTO.setPrefix(visitor.getPrefix());

        return visitorDTO;
    }

}
