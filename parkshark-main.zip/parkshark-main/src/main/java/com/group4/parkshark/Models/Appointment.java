package com.group4.parkshark.Models;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name="appointments")
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class Appointment {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;
    @Column(name = "manager_id", nullable = false)
    private long managerId;
    @Column(name = "visitor_id", nullable = false)
    private long visitorId;
    @Column(name = "user_id", nullable = false)
    private long userId;
    @Column(name = "starts_at", nullable = false)
    private Date startsAt;
    @Column(name = "ends_at", nullable = false)
    private Date endsAt;
    @Column(name = "created_at", nullable = true)
    private Date createdAt;
    @Column(name = "updated_at", nullable = true)
    private Date updatedAt;
}
