package com.group4.parkshark.Repositories;

import com.group4.parkshark.Models.ParkingSpot;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface IParkingLotRepository extends JpaRepository<ParkingSpot, Long> {
    Optional<ParkingSpot> findByParkingspot(int parkingspot);
}
