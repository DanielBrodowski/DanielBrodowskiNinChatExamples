package com.group4.parkshark.DTOs;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import java.util.Date;

@Data
public class UserDTO {

    private Long id;
    private String name;
    private String email;
    private String email_verified_at;
    private String password;
    private String remember_token;
    private Date created_at;
    private Date updated_at;
}
