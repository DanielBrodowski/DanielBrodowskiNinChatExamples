package com.group4.parkshark.Controllers;

import com.group4.parkshark.DTOs.AppointmentDTO;
import com.group4.parkshark.Models.Appointment;
import com.group4.parkshark.Models.Manager;
import com.group4.parkshark.Repositories.IAppointmentRepository;
import com.group4.parkshark.Repositories.IManagerRepository;
import com.group4.parkshark.Services.AppointmentService;
import com.group4.parkshark.Services.ManagerService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins = "http://localhost:3000", allowedHeaders = "*")
@RestController
@RequiredArgsConstructor
public class ManagerController {
    private final ManagerService service;
    private final IManagerRepository managersRepository;

    @GetMapping("/managers")
    public ResponseEntity<List<Manager>> getAllManagers() {
        List<Manager> managers = service.getAllManagers();
        return ResponseEntity.ok().body(managers);
    }

    @GetMapping("/managers/{id}")
    public ResponseEntity<Manager> getManagerById(@PathVariable(value = "id") Long id) {
        Manager manager = service.getManager(id);
        if (manager != null) {
            return ResponseEntity.ok().body(manager);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @PostMapping("/managers/create")
    public Manager createManager(@RequestBody Manager manager) {

        return service.createManager(manager);
    }

    @PutMapping("/managers/update")
    public ResponseEntity<String> updateManager(@RequestBody Manager manager) {
        return ResponseEntity.ok("Manager successfully updated");
    }

    @DeleteMapping("/managers/delete/{id}")
    public ResponseEntity deleteAppointment(@PathVariable(value = "id") Long id) {
        service.deleteManager(id);
        return ResponseEntity.ok().build();

    }
}
