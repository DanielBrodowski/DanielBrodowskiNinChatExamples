package com.group4.parkshark.Services;

import com.group4.parkshark.Models.User;
import com.group4.parkshark.Repositories.IUserRepo;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import javax.persistence.EntityNotFoundException;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class UserService {
    private final IUserRepo repo;
    private final BCryptPasswordEncoder passwordEncoder;

    public List<User> getAllUsers(){

        return repo.findAll();
    }

    public User getUserByName(String name){
        return repo.findByName(name).orElseThrow(EntityNotFoundException::new);
    }

    public User getUser(Long Id){

        return repo.findById(Id).orElse(null);
    }
    public User createUser(User user){
        User toCreateUser = new User();
        Optional<User> byUname = repo.findByName(user.getName());
        if(byUname.isPresent()){
            throw new RuntimeException("User with the user name: ["+ user.getName() + "] already exists");
        }
        //sets the values of the user object thats going to be saved
        toCreateUser.setName(user.getName());
        toCreateUser.setEmail(user.getEmail());
        toCreateUser.setPassword(user.getPassword());
        toCreateUser.setPassword(passwordEncoder.encode(user.getPassword()));
        toCreateUser.setRole("ADMIN");
        return repo.save(toCreateUser);
    }
    public void deleteUser(Long Id){

        repo.deleteById(Id);
    }
    public boolean updateUser(User updUser){

        User user = repo.findById(updUser.getId()).orElse(null);
        if(user != null){
            updUser.setPassword(passwordEncoder.encode(user.password));
            repo.save(updUser);
            return true;
        }
        else {
            return false;
        }
    }
}
