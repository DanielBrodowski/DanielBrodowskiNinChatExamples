package com.group4.parkshark.Services;

import com.group4.parkshark.DTOs.ParkingSpotDTO;
import com.group4.parkshark.Models.ParkingSpot;
import com.group4.parkshark.Repositories.IParkingLotRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import javax.persistence.EntityNotFoundException;
import java.util.*;

@Service
@RequiredArgsConstructor
public class ParkingLotService {
    private final IParkingLotRepository repo;


    public ParkingSpot getParkingLot(int parkingSpotNumber) throws EntityNotFoundException {
        return repo.findByParkingspot(parkingSpotNumber).orElse(null);



        }
    public void setAsOccupied(ParkingSpotDTO parkingSpotDTO){
        ParkingSpot parkingSpot = new ParkingSpot();
        boolean occupied = parkingSpotDTO.isOccupied();
        parkingSpot.setId((long) parkingSpotDTO.getSpotNumber());
        parkingSpot.setParkingspot(parkingSpotDTO.getSpotNumber());
        parkingSpot.setOccupied(occupied);
        repo.save(parkingSpot);
    }

    public List<ParkingSpotDTO> getAllSpots(){
        List<ParkingSpotDTO> parkingSpotDTOS = createDTOListFromModelList(repo.findAll());
        return parkingSpotDTOS;
    }


    //creates a DTO from a ParkingSpot Models
    private ParkingSpotDTO createDTOFromModel(ParkingSpot model){
        ParkingSpotDTO parkingSpotDTO = new ParkingSpotDTO();
        parkingSpotDTO.setSpotNumber(model.getParkingspot());
        parkingSpotDTO.setOccupied(model.isOccupied());
        return parkingSpotDTO;
    }
    //creates a List of parkingSpot DTOs from a list of ParkingSpot Models
    private List<ParkingSpotDTO> createDTOListFromModelList(List<ParkingSpot> models){
        List<ParkingSpotDTO> parkingSpotDTOS = new ArrayList<>();
        for (ParkingSpot parkingspot:models)
        {
            parkingSpotDTOS.add(createDTOFromModel(parkingspot));
        }
        return parkingSpotDTOS;

    }
}
