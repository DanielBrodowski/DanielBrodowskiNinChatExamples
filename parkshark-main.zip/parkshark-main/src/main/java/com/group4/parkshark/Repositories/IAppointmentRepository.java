package com.group4.parkshark.Repositories;

import com.group4.parkshark.Models.Appointment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@EnableJpaRepositories(basePackages = "com.springboot.reserving.member")
@Repository
public interface IAppointmentRepository extends JpaRepository<Appointment, Long> {
    Optional<Appointment> findByVisitorId(Long visitorId);
}
