import React, {Component} from 'react';
import {withRouter} from "react-router-dom";
import {Button, Form, FormGroup, Input, Label} from 'reactstrap';
import 'bootstrap/dist/css/bootstrap.min.css';
import AppointmentsService from '../Service/AppointmentsService';
import ManagersService from '../Service/ManagersService';
import VisitorService from '../Service/VisitorService';
import moment from "moment";
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';

moment.locale("nl-NL");

class CreateAppForm extends Component {
    appItem = {
        managerId: '',
        startsAt: '',
        userId: 1,
        endsAt: '',
    };

    visItem = {
        id: '',
        firstName: '',
        lastName: '',
        phone: '',
        email: '',
        licensePlate: ''
    };

    constructor(props) {
        super(props);
        this.state = {
            man: [],
            vis: [],
            visitor: this.visItem,
            app: this.appItem
        };
        this.handleSubmit = this.handleSubmit.bind(this);

    }

    componentDidMount() {
        this.setState({});

        VisitorService.getAllVisitors().then((response) => {
            this.setState({vis: response.data})
        });

        ManagersService.getAllManagers().then((response) => {
            this.setState({man: response.data})
        });
    }

    convertDate = (date) => {
        return moment.utc(date).add(1, "hours").format("YYYY-MM-DThh:mm")
    }

    async handleSubmit(event) {
        event.preventDefault();
        const {app} = this.state;
        const {visitor} = this.state;

        visitor.firstName = document.getElementById("first_name").value;
        visitor.lastName = document.getElementById("last_name").value;
        visitor.email = document.getElementById("email").value;
        visitor.phone = document.getElementById("phone").value;
        visitor.licensePlate = document.getElementById("license_plate").value;

        await VisitorService.addNewVisitor(visitor);

        this.setState({});

        VisitorService.getAllVisitors().then((response) => {
            this.setState({vis: response.data})
        });
        console.log(this.state.vis)
        visitor.id = this.state.vis.filter(item => item.email = visitor.email)[0].id;
        console.log(visitor.id);

        app.visitorId = visitor.id;
        app.managerId = document.getElementById("manager_id").value;
        app.startsAt = document.getElementById("starts_at").value;
        app.endsAt = document.getElementById("ends_at").value;

        await AppointmentsService.addNewAppointment(app);

        this.props.handleCloseModalCreate();

    }

    render() {
        const {man} = this.state;
        const {vis} = this.state;
        const title = <h2>Create appointment</h2>;
        const {startDate, endDate} = this.props;
        console.log(startDate, endDate);

        return (
            <div className="content">
                <Container>
                    {title}
                    <Form onSubmit={this.handleSubmit}>
                        <Row>
                            <Col>
                                <FormGroup>
                                    <Label for="manager">Manager</Label>
                                    <Input type="select" name="manager_id" id="manager_id" onChange={this.handleChange}
                                           autoComplete="manager_id">
                                        {
                                            man.map(manager => (
                                                <option key={manager.id}
                                                        value={manager.id}>{manager.first_name} {manager.last_name}</option>
                                            ))}
                                    </Input>
                                </FormGroup>

                                <FormGroup>
                                    <Label for="last_name">Visitor Last Name</Label>
                                    <Input type="text" required name="last_name" id="last_name">
                                    </Input>
                                </FormGroup>

                                <FormGroup>
                                    <Label for="email">Visitor Email</Label>
                                    <Input type="email" required name="email" id="email">
                                    </Input>
                                </FormGroup>

                                <FormGroup>
                                    <Label for="phone">Visitor Phone Number</Label>
                                    <Input type="text" required name="phone" id="phone">
                                    </Input>
                                </FormGroup>
                            </Col>

                            <Col>
                                <FormGroup>
                                    <Label for="first_name">Visitor First Name</Label>
                                    <Input type="text" required name="first_name" id="first_name">
                                    </Input>
                                </FormGroup>

                                <FormGroup>
                                    <Label for="start">Start</Label>
                                    <Input type="datetime-local" name="starts_at" id="starts_at"
                                           onChange={this.handleChange} value={this.convertDate(startDate) || ''}
                                           autoComplete="starts_at"/>
                                </FormGroup>
                                <FormGroup>
                                    <Label for="end">End</Label>
                                    <Input type="datetime-local" name="ends_at" id="ends_at"
                                           onChange={this.handleChange} value={this.convertDate(endDate) || ''}
                                           autoComplete="ends_at"/>
                                </FormGroup>

                                <FormGroup>
                                    <Label for="license_plate">License</Label>
                                    <Input type="text" name="license_plate" id="license_plate"
                                           onChange={this.handleChange} autoComplete="license_plate"/>
                                </FormGroup>
                            </Col>
                        </Row>
                        <FormGroup>
                            <Button color="primary" type="submit">Save</Button>{' '}
                        </FormGroup>
                    </Form>
                </Container>
            </div>
        )
    }
}

export default withRouter(CreateAppForm);
