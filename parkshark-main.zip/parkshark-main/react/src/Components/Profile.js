import React, {Component} from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import AuthService from '../Service/AuthService';
import {withRouter} from "react-router-dom";
import Header from "./Header"
class Profile extends Component {
    constructor(props) {
        super(props);
        this.state = {
            currentUser: AuthService.getCurrentUser()
        };
    }
    componentDidMount() {
        this.setState({});
    }
    render() {
        const {currentUser} = this.state;
        return (
            <div>
                <Header/>
                <div className="homeBg">
                    <div className="homeOverlay">
                        <div className="content-50">
                            <p>
                                <strong>Id:</strong>{" "}
                                {currentUser.id}
                            </p>
                            <p>
                                <strong>Email:</strong>{" "}
                                {currentUser.email}
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        )
            ;
    }
}
export default withRouter(Profile);
