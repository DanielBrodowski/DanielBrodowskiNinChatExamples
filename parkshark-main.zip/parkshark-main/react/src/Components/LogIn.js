import React, {Component} from 'react';
import '../App.css';
import {withRouter} from 'react-router-dom';
import Form from "react-validation/build/form";
import CheckButton from "react-validation/build/button";
import AuthService from '../Service/AuthService';
import HeaderGuest from "./HeaderGuest";

const required = value => {
    if (!value) {
        return (
            <div className="alert alert-danger" role="alert">
                This field is required!
            </div>
        );
    }
};

class LogIn extends Component {
    constructor(props) {
        super(props);
        this.handleLogin = this.handleLogin.bind(this);
        this.onChangeName = this.onChangeName.bind(this);
        this.onChangePassword = this.onChangePassword.bind(this);

        this.state = {
            name: "",
            password: "",
            loading: false,
            message: ""
        };
    }

    onChangeName(e) {
        this.setState({
            name: e.target.value
        });
    }

    onChangePassword(e) {
        this.setState({
            password: e.target.value
        });
    }

    handleLogin(e) {
        e.preventDefault();

        this.setState({
            message: "",
            loading: true
        });

        this.form.validateAll();
        

        if (this.checkBtn.context._errors.length === 0) {
            
            AuthService.login({name: this.state.name, password: this.state.password}).then(
                () => {
                    this.props.history.push("/appointments");
                    window.location.reload();
                },
                error => {
                    this.setState({
                        loading: false,
                        message: error.response.data.message
                    });
                }
            );
        } else {
            this.setState({
                loading: false
            });
        }
    }

    componentDidMount() {
        this.setState({});
    }

    render() {

        return (
            <div>
                <HeaderGuest/>
                <div className="homeBg">
                    <div className="homeOverlay">
                        <div className="content-50">
                            <Form onSubmit={this.handleLogin} ref={c => {
                                this.form = c;
                            }}>
                                <div className="form-group">
                                    <label htmlFor="name">Name</label>
                                    <input type="text"
                                           className="form-control"
                                           name="name"
                                           value={this.state.name}
                                           onChange={this.onChangeName}
                                           validations={[required]}/>
                                </div>
                                <div className="form-group">
                                    <label htmlFor="password">Password</label>
                                    <input type="password"
                                           className="form-control"
                                           name="password"
                                           value={this.state.password}
                                           onChange={this.onChangePassword}
                                           validations={[required]}/>
                                </div>
                                <br/>
                                <div className="form-group">
                                    <button className="btn btn-primary btn-block"
                                            disabled={this.state.loading}>
                                        {this.state.loading && (
                                            <span className="spinner-border spinner-border-sm"></span>
                                        )} <span>Login</span>
                                    </button>
                                    {' '}

                                </div>
                                {this.state.message && (
                                    <div className="form-group">
                                        <div className="alert alert-danger" role="alert">
                                            {this.state.message}
                                        </div>
                                    </div>
                                )}
                                <CheckButton
                                    style={{display: "none"}}
                                    ref={c => {
                                        this.checkBtn = c;
                                    }}
                                />
                            </Form>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}

export default withRouter(LogIn)