import React, {Component} from 'react';
import {withRouter} from "react-router-dom";
import {Button, Container, Form, FormGroup, Input, Label} from 'reactstrap';
import 'bootstrap/dist/css/bootstrap.min.css';
import moment from "moment";
import AppointmentsService from '../Service/AppointmentsService';
import {confirmAlert} from 'react-confirm-alert';
import ManagersService from "../Service/ManagersService";
import VisitorService from "../Service/VisitorService"; // Import

moment.locale("nl-NL");


class AppointmentsEdit extends Component {
    appointment = {
        id: '',
        managerId: '',
        visitorId: '',
        startsAt: '',
        endsAt: '',
        updated_at: '',
        start: '',
        end: ''
    };

    manager = {
        id: '',
        first_name: '',
        last_name: '',
        email: ''
    }

    visitor = {
        id: '',
        firstName: '',
        lastName: '',
        phone: '',
        email: '',
        licensePlate: ''
    }

    constructor(props) {
        super(props);
        this.state = {
            item: this.appointment,
            man: this.manager,
            vis: this.visitor
        };
        this.handleSubmit = this.handleSubmit.bind(this);
        this.onChangePhone = this.onChangePhone.bind(this);
        this.onChangeLicense = this.onChangeLicense.bind(this);
        this.onChangeEmail = this.onChangeEmail.bind(this);
    }

    async componentDidMount() {
        const {appId} = this.props;

        if (appId !== 'new') {
            await AppointmentsService.getAppointmentById(appId).then((response) => {
                this.setState({item: response.data})
            });
        }
        await ManagersService.getManagerById(this.state.item.managerId).then((response) => {
            this.setState({man: response.data})
        });
        await VisitorService.getVisitorsById(this.state.item.visitorId).then((response) => {
            this.setState({vis: response.data})
        });


    }

    async remove(id) {
        confirmAlert({
            title: 'Confirm to delete',
            message: 'Are you sure you want to delete this appointment?',
            buttons: [
                {
                    label: 'Yes',
                    onClick: () => AppointmentsService.deleteAppointment((id)).then(() => {
                        this.setState({});
                        AppointmentsService.getAllAppointments().then((response) => {
                            this.setState({appointments: response.data})
                        });

                        this.props.handleCloseModale();
                    })
                },
                {
                    label: 'No',
                    onClick: () =>
                        this.props.handleCloseModale()

                }
            ]
        });
    }

    onChangePhone(e) {
        const phone = e.target.value;
        this.setState(function (prevState) {
            return {
                vis: {
                    ...prevState.vis,
                    phone: phone
                }
            };
        });
    }

    onChangeEmail(e) {
        const email = e.target.value;
        this.setState(function (prevState) {
            return {
                vis: {
                    ...prevState.vis,
                    email: email
                }
            };
        });
    }

    onChangeLicense(e) {
        const plate = e.target.value;
        this.setState(function (prevState) {
            return {
                vis: {
                    ...prevState.vis,
                    licensePlate: plate
                }
            };
        });
    }

    convertDate = (date) => {
        return moment.utc(date).add(1, "hours").format("YYYY-MM-DThh:mm")
    }

    async handleSubmit(event) {
        event.preventDefault();
        const {item} = this.state;
        await fetch('/appointments/update/' + item.id, {
            method: (item.id) ? 'PUT' : 'POST',
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(item),
        });
        this.setState({showModal: false})

        this.props.history.push('/');
    }

    render() {
        const {item} = this.state;
        const {man} = this.state;
        const {vis} = this.state;
        const title = <h2>Edit appointment</h2>;
        return (
            <div className="content">
                <Container>
                    {title}
                    <Form onSubmit={this.handleSubmit}>
                        <FormGroup>
                            <Label for="manager">Manager</Label>
                            <Input type="text" name="manager_id" id="manager_id"
                                   value={man.first_name + " " + man.last_name}
                                   placeholder={man.id || ''} disabled
                                   autoComplete="manager_id"/>
                        </FormGroup>
                        <FormGroup>
                            <Label for="vname">Visitor</Label>
                            <Input type="text" name="vname" id="vname" disabled placeholder={vis.id || ''}
                                   value={vis.firstName + " " + vis.lastName}
                                   autoComplete="visitor_id"/>
                        </FormGroup>
                        <FormGroup>
                            <Label for="vname">Visitor Email</Label>
                            <Input type="email" name="email" id="email"
                                   value={vis.email || ''} onChange={this.onChangeEmail} autoComplete="email"/>
                        </FormGroup>
                        <FormGroup>
                            <Label for="vphone">Visitor Phone</Label>
                            <Input type="text" name="phone" className="form-control"
                                   value={vis.phone} onChange={this.onChangePhone} autoComplete="phone"/>
                        </FormGroup>
                        <FormGroup>
                            <Label for="start">Start</Label>
                            <Input type="datetime-local" name="starts_at" id="starts_at"
                                   value={this.convertDate(item.startsAt) || ''} disabled
                                   autoComplete="starts_at"/>
                        </FormGroup>
                        <FormGroup>
                            <Label for="end">End</Label>
                            <Input type="datetime-local" name="ends_at" id="ends_at"
                                   value={this.convertDate(item.endsAt) || ''} disabled
                                   autoComplete="ends_at"/>
                        </FormGroup>
                        <FormGroup>
                            <Label for="license_plate">License</Label>
                            <Input type="text" name="license_plate" id="license_plate" value={vis.licensePlate || ''}
                                   onChange={this.onChangeLicense} autoComplete="license_plate"/>
                        </FormGroup>
                        <FormGroup>
                            <Button color="primary" type="submit">Update</Button>{' '}
                            <Button color="secondary" onClick={() => this.remove(item.id)}>Delete</Button>
                        </FormGroup>
                    </Form>
                </Container>
            </div>
        )
    }
}

export default withRouter(AppointmentsEdit);