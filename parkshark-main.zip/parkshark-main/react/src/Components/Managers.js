import React, { Component } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Accordion from 'react-bootstrap/Accordion';
import ManagersService from '../Service/ManagersService';
import Header from './Header';
import { CSVReader } from 'react-papaparse';
import { Button} from 'reactstrap';
import { confirmAlert } from 'react-confirm-alert'; // Import
import 'react-confirm-alert/src/react-confirm-alert.css'; // Import css
import { CSVLink } from "react-csv";

class Managers extends Component {
    emptyItem = {
        first_name: '',
        last_name: '',
        prefix: '',
        email: ''
    };

    constructor(props) {
        super(props)
        this.state = {
            managers: [],
            item: this.emptyItem
        }
    }

    componentDidMount() {
        this.setState({});
        ManagersService.getAllManagers().then((response) => {
            this.setState({ managers: response.data })
            console.log(response.data);
        });
    }

    handleOnDrop = (data) => {
        console.log('---------------------------')

        data.forEach(element => {

            const { item } = this.state;
            item.first_name = element.data[3];
            item.prefix = element.data[4];
            item.last_name = element.data[5];
            item.email = element.data[6];
            ManagersService.addNewManager(item);
            console.log(item)


        })
        this.setState({});
        ManagersService.getAllManagers().then((response) => {
            this.setState({ managers: response.data })
        });

        this.props.history.push('/managers');

    }

    handleOnError = (err, file, inputElem, reason) => {
        console.log(err)
    }

    handleOnRemoveFile = (data) => {
        console.log('---------------------------')
        console.log(data)
        console.log('---------------------------')
    }
    async remove(id) {
        confirmAlert({
            title: 'Confirm to delete',
            message: 'Are you sure you want to delete this manager?',
            buttons: [
                {
                    label: 'Yes',
                    onClick: () => ManagersService.deleteManager((id)).then(() => {
                        this.setState({});
                        ManagersService.getAllManagers().then((response) => {
                            this.setState({ managers: response.data })
                        });
                    })
                },
                {
                    label: 'No',
                    onClick: () => alert('Click No')
                }
            ]
        });
    }
    render() {
        const { managers } = this.state;

        const headers = [
            { label: "Id", key: "id" },
            { label: "Created at", key: "created_at" },
            { label: "Updated at", key: "updated_at" },
            { label: "First Name", key: "first_name" },
            { label: "Prefix", key: "prefix" },
            { label: "Last Name", key: "last_name" },
            { label: "Email", key: "email" }
        ];

        const csvReport = {
            data: managers,
            headers: headers,
            filename: 'Managers.csv'
        };


        console.log(managers);
        return (
            <div>
                <Header />
                <div className="containerAccordion">
                    <Container>
                        <Row>
                            <Col>
                            <CSVLink  {...csvReport} separator={";"}>Download CSV</CSVLink>
                                <Accordion>
                                    {managers.map(manager => {
                                        if (manager.prefix != 'null')
                                            return <Accordion.Item eventKey={manager.id}>
                                                <Accordion.Header>{manager.first_name} {manager.prefix} {manager.last_name}</Accordion.Header>
                                                <Accordion.Body>
                                                    {manager.email}
                                                    <br />
                                                    <Button onClick={() => this.remove(manager.id)}> Delete</Button>
                                                </Accordion.Body>
                                            </Accordion.Item>

                                        return <Accordion.Item eventKey={manager.id}>
                                            <Accordion.Header>{manager.first_name} {manager.last_name}</Accordion.Header>
                                            <Accordion.Body>
                                                {manager.email}<br />

                                                <Button onClick={() => this.remove(manager.id)}> Delete</Button>

                                            </Accordion.Body>
                                        </Accordion.Item>
                                    })}
                                </Accordion>
                            </Col>
                            <Col>

                                <CSVReader
                                    onDrop={this.handleOnDrop}
                                    onError={this.handleOnError}
                                    addRemoveButton
                                    removeButtonColor='#659cef'
                                    onRemoveFile={this.handleOnRemoveFile}
                                >
                                    <span>Drop CSV file here or click to upload.</span>
                                </CSVReader>
                            </Col>
                        </Row>
                    </Container>

                </div>
            </div>
        );
    }
}
export default Managers;