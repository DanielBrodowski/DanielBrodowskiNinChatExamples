import axios from 'axios'
import authHeader from "./auth-header";
const API_URL = "http://localhost:3000/";

class ManagersService {

    getAllManagers(){
        return axios.get(API_URL+ "managers");
    }

    addNewManager(data){
        return axios.post(API_URL + "managers/create", data,{headers: authHeader()} );
    }

    deleteManager(id){
        return axios.delete(API_URL + "managers/delete/" + id, {headers: authHeader()});
    }

    getManagerById(id){
        return axios.get(API_URL + 'managers/' + id, {headers: authHeader()});
    }
}
export default new ManagersService();