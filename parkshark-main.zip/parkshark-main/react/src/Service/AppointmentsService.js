import axios from 'axios'
import authHeader from "./auth-header";
const API_URL = "http://localhost:3000/";

class AppointmentsService {

    getAllAppointments(){
        return axios.get(API_URL+ "appointments", {headers: authHeader()});
    }

    addNewAppointment(data){
        return axios.post(API_URL+ "appointments/save", data,{headers: authHeader()});
    }

    deleteAppointment(id){
        return axios.delete(API_URL + "appointments/delete/" + id, {headers: authHeader()});
    }


    getAppointmentById(id){
        return axios.get(API_URL + 'appointments/' + id, {headers: authHeader()});
    }

}
export default new AppointmentsService();