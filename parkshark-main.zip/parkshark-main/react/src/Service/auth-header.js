export default function authHeader() {
    const user = localStorage.getItem('user');
    const token = localStorage.getItem('token');
    console.log(user, token)
    if (user && token) {
        return { Authorization: 'Bearer ' + token};
    } else {
        return {};
    }
}