import axios from 'axios'

const API_URL = "http://localhost:8080/";
class AuthService {
    login(data) {
        return axios.post(API_URL + "login", data).then(response => {
            console.log("response: ", response)
            localStorage.setItem("user", data.name);
            localStorage.setItem("token", response.data.Authorization);
              

            return response.data;
        });
    };

    logout() {
        localStorage.removeItem("user");
        localStorage.removeItem("token");
    }

    register(data) {
        return axios.post(API_URL + "user/save", data).then(response => {
            console.log(response);
        });
    }

    getCurrentUser() {
        return (localStorage.getItem('user'));
    }
}

export default new AuthService();