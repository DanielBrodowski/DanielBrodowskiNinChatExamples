import axios from 'axios'
import authHeader from "./auth-header";
const API_URL = "http://localhost:3000/";

class VisitorService {

    getAllVisitors(){
        return axios.get(API_URL+ "visitors");
    }

    addNewVisitor(data){
        return axios.post(API_URL + "visitors/create", data);
    }

    getVisitorsById(id){
        return axios.get(API_URL + 'visitors/' + id, {headers: authHeader()});
    }
}
export default new VisitorService();