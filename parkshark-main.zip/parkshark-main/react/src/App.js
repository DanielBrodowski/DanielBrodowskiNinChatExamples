import React, {Component} from "react";
import './App.css';
import "bootstrap/dist/css/bootstrap.min.css";
import 'react-confirm-alert/src/react-confirm-alert.css'; // Import css
import {BrowserRouter, Route, Switch} from "react-router-dom";
import {LogIn, Home, Profile, SignUp, Appointments, AppointmentsEdit, Managers} from './components';
import AuthService from "./Service/AuthService";

class App extends Component {
    logOut() {
        AuthService.logout();
    }

    render() {
        return (
            <div className="App">

                <Switch>
                    <Route path="/appointments" exact component={Appointments}/>
                    <Route path="/" exact component={LogIn}/>
                    <Route path="/signup" exact component={SignUp}/>
                    <Route path='/appointments/:id' component={AppointmentsEdit}/>
                    <Route path="/appointmentsList" exact component={Home}/>
                    <Route path="/profile" exact component={Profile}/>
                    <Route path="/managers" exact component={Managers}/>
                </Switch>
            </div>
        );
    }
}

export default App;