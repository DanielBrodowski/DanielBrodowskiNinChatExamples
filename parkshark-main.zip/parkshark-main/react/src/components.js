export { default as Appointments } from "./Components/Appointments";
export { default as LogIn } from "./Components/LogIn";
export { default as Home } from "./Components/Home";
export { default as Header } from "./Components/Header";
export { default as SignUp } from "./Components/SignUp";
export { default as Profile } from "./Components/Profile";
export { default as AppointmentsEdit } from "./Components/AppointmentsEdit";
export { default as Managers } from "./Components/Managers";