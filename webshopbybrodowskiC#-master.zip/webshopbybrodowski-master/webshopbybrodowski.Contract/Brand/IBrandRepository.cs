﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Text;
using webshopbybrodowski.Contract.Repository;
using webshopbybrodowski.Models;

namespace webshopbybrodowski.Contract.Brand
{
    public interface IBrandRepository : IRepository<Models.Brand>
    {
        IEnumerable<SelectListItem> GetBrandListForDropdown();

        void Update(Models.Brand brand);
    }
}
