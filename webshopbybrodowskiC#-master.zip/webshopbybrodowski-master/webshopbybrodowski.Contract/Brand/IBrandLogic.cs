﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Text;

namespace webshopbybrodowski.Contract.Brand
{
    public interface IBrandLogic
    {
        IEnumerable<BrandDto> GetAll();
        BrandDto GetId(int? id);
        BrandDto Upsert(BrandDto createCategoryDto);
        BrandDto Delete(int? id);
        IEnumerable<SelectListItem> GetDropDown();
    }
}
