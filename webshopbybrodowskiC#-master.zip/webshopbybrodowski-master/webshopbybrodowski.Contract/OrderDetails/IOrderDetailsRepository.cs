﻿using System;
using System.Collections.Generic;
using System.Text;
using webshopbybrodowski.Contract.Repository;

namespace webshopbybrodowski.Contract.OrderDetails
{
    public interface IOrderDetailsRepository : IRepository<Models.OrderDetails>
    {

    }
}
