﻿using System;
using System.Collections.Generic;
using System.Text;

namespace webshopbybrodowski.Contract.OrderDetails
{
    public interface IOrderDetailsLogic
    {
        OrderDetailsDto AddOrderDetails(OrderDetailsDto model);
    }
}
