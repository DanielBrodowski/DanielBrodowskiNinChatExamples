﻿using System;
using System.Collections.Generic;
using System.Text;
using webshopbybrodowski.Contract.Order;
using webshopbybrodowski.Contract.Product;

namespace webshopbybrodowski.Contract.OrderDetails
{
    public class OrderDetailsDto
    {
        public int Id { get; set; }
        public int OrderId { get; set; }
        public OrderDto Order { get; set; }
        public int ProductId { get; set; }
        public ProductDto Product { get; set; }
        public double Price { get; set; }
    }
}
