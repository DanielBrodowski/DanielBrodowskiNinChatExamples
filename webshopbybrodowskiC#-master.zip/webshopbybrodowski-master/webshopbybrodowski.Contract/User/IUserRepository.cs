﻿using System;
using System.Collections.Generic;
using System.Text;
using webshopbybrodowski.Contract.Repository;

namespace webshopbybrodowski.Contract.User
{
    public interface IUserRepository : IRepository<Models.User>
    {
        void LockedUser(string id);
        void UnlockUser(string id);
    }
}
