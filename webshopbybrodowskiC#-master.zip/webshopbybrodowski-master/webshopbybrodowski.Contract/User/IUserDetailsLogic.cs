﻿using System;
using System.Collections.Generic;
using System.Text;

namespace webshopbybrodowski.Contract.User
{
    public interface IUserDetailsLogic
    {
        UserDto GetFirstOfDefault(string id);
    }
}
