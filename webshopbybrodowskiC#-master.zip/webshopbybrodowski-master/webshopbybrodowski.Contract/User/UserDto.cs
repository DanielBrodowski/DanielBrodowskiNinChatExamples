﻿using System;
using System.Collections.Generic;
using System.Text;

namespace webshopbybrodowski.Contract.User
{
    public class UserDto
    {
        public string Firstname { get; set; }
        public string Surname { get; set; }
        public string Address { get; set; }
        public string Residence { get; set; }
        public string Postalcode { get; set; }
        public string Housenumber { get; set; }

        public string Role { get; set; }
    }
}
