﻿using System;
using System.Collections.Generic;
using System.Text;
using webshopbybrodowski.Contract.Identity;

namespace webshopbybrodowski.Contract.Factory
{
    public interface IFactory
    {
        IRegisterLogic Register { get; }
        ILoginLogic Login { get; }
        ILogOutLogic LogOut { get; }
    }
}
