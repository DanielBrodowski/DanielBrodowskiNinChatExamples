﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;

namespace webshopbybrodowski.Contract.Repository
{
    public interface IRepository<T> where T : class //interface for generic repository of class
    {
        T Get(int id);

        IEnumerable<T> GetAll(
            Expression<Func<T, bool>> filter = null,
            Func<IQueryable<T>, IOrderedEnumerable<T>> orderBy = null,
            string includeProperties = null
            ); //using linq to filter or order results

        T GetFirstOrDefault(
            Expression<Func<T, bool>> filter = null,
            string includeProperties = null
            );

        void Add(T entity);

        void Remove(int id); //Entity can be removed with id
        void Remove(T entity); //Can also pass a whole entity to remove
    }
}
