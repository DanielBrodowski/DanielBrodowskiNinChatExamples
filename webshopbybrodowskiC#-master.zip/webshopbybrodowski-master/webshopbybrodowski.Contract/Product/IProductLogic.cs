﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Text;

namespace webshopbybrodowski.Contract.Product
{
    public interface IProductLogic
    {
        IEnumerable<ProductDto> GetAll();
        ProductDto GetId(int? id);
        ProductDto Upsert(ProductDto productDto);
        ProductDto Delete(int? id);
        ProductDto CreateImagePath(ProductDto productDto, IFormFileCollection files);
        ProductDto GetFirstOrDefault(int? id);
    }
}
