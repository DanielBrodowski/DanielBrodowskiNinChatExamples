﻿using System;
using System.Collections.Generic;
using System.Text;
using webshopbybrodowski.Contract.Repository;
using webshopbybrodowski.Models;

namespace webshopbybrodowski.Contract.Product
{
    public interface IProductRepository : IRepository<Models.Product>
    {

        void Update(Models.Product product);
    }
}
