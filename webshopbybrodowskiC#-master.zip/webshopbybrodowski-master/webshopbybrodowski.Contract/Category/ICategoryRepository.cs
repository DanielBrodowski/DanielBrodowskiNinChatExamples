﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Text;
using webshopbybrodowski.Contract.Repository;
using webshopbybrodowski.Models;

namespace webshopbybrodowski.Contract.Category
{
   public interface ICategoryRepository : IRepository<Models.Category>
    {
        IEnumerable<SelectListItem> GetCategoryListForDropdown();

        void Update(Models.Category category);

    }
}
