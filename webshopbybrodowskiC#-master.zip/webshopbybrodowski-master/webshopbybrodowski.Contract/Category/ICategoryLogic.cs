﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Text;

namespace webshopbybrodowski.Contract.Category
{
    public interface ICategoryLogic
    {
        IEnumerable<CategoryDto> GetAll();
        CategoryDto Upsert(CategoryDto createCategoryDto);
        CategoryDto GetId(int? id);
        CategoryDto Delete(int? id);
        IEnumerable<SelectListItem> GetDropDown();
    }
}
