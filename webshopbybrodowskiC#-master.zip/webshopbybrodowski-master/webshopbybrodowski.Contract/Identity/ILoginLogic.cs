﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace webshopbybrodowski.Contract.Identity
{
    public interface ILoginLogic
    {
        Task<bool> Login(Models.User model);
    }
}
