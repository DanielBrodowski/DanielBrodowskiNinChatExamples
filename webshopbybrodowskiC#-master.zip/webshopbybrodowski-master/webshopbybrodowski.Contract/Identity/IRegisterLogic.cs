﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace webshopbybrodowski.Contract.Identity
{
    public interface IRegisterLogic
    {
        Task<Models.User> SignUp(Models.User model);
    }
}
