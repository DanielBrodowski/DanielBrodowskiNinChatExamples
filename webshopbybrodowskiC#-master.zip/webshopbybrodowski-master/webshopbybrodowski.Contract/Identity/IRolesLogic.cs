﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace webshopbybrodowski.Contract.Identity
{
    public interface IRolesLogic
    {
        void RolesCheck();

        Task<Models.User> AddToRole(Models.User user);
    }
}
