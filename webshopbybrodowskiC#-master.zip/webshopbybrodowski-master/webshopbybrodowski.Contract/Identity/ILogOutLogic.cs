﻿using System;
using System.Collections.Generic;
using System.Text;

namespace webshopbybrodowski.Contract.Identity
{
   public interface ILogOutLogic
    {
        void LogOutUser();
    }
}
