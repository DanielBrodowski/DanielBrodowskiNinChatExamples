﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using webshopbybrodowski.Contract.Brand;
using webshopbybrodowski.Contract.Category;
using webshopbybrodowski.Contract.Order;
using webshopbybrodowski.Contract.OrderDetails;
using webshopbybrodowski.Contract.Product;
using webshopbybrodowski.Contract.User;

namespace webshopbybrodowski.Contract.UnitOfWork
{
    public interface IUnitOfWork
    {
        ICategoryRepository Category { get; }
        IBrandRepository Brand { get; }
        IProductRepository Product { get; }
        IOrderHeaderRepository Order { get; }
        IOrderDetailsRepository OrderDetails { get; }
        IUserRepository User { get; }

        void Save();

    }
}
