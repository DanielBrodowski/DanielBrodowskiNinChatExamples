﻿using System;
using System.Collections.Generic;
using System.Text;

namespace webshopbybrodowski.Contract.Order
{
    public interface IOrderLogic
    {
        OrderDto GetFirstOrDefault(OrderDto model);
        OrderDto AddOrder(OrderDto model);
    }
}
