﻿using System;
using System.Collections.Generic;
using System.Text;
using webshopbybrodowski.Contract.User;

namespace webshopbybrodowski.Contract.Order
{
    public class OrderDto
    {
        public int Id { get; set; }


        public string UserId { get; set; }


        public UserDto User { get; set; }


        public DateTime RentDate { get; set; }


        public DateTime ReturnDate { get; set; }

        public double Total { get; set; }
    }
}
