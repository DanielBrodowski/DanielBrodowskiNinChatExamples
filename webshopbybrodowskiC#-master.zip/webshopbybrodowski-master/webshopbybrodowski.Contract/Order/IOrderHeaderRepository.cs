﻿using System;
using System.Collections.Generic;
using System.Text;
using webshopbybrodowski.Contract.Repository;

namespace webshopbybrodowski.Contract.Order
{
    public interface IOrderHeaderRepository : IRepository<Models.OrderHeader>
    {
    }
}
