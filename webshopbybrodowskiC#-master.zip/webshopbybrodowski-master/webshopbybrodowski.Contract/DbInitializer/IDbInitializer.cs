﻿using System;
using System.Collections.Generic;
using System.Text;

namespace webshopbybrodowski.Contract.DbInitializer
{
    public interface IDbInitializer
    {
        void Initializer();
    }
}
