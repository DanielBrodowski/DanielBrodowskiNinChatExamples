﻿using System;
using System.Collections.Generic;
using System.Text;

namespace webshopbybrodowski.Utility
{
    public static class Session
    {

        public const string SessionCart = "Cart";
        public const string StatusApproved = "Approved";
        public const string StatusSubmitted = "Submitted";
        public const string StatusRejected = "Rejected";

    }
}
