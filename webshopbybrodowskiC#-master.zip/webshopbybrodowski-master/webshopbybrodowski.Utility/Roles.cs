﻿using System;
using System.Collections.Generic;
using System.Text;

namespace webshopbybrodowski.Utility
{
    public static class Roles
    {
        public const string Admin = "Admin";
        public const string User = "User";
    }
}
