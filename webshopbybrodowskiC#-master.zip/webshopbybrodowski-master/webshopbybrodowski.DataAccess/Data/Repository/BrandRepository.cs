﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using webshopbybrodowski.Contract.Brand;
using webshopbybrodowski.Models;

namespace webshopbybrodowski.DataAccess.Data.Repository
{
    public class BrandRepository : Repository<Brand>, IBrandRepository
    {
        private readonly ApplicationDbContext _db;

        public BrandRepository(ApplicationDbContext db) : base(db)
        {
            _db = db;
        }

        public IEnumerable<SelectListItem> GetBrandListForDropdown()
        {
            return _db.Brand.Select(i => new SelectListItem()
            {
                Text = i.Name,
                Value = i.Id.ToString()
            });
        }

        public void Update(Brand brand)
        {
            var objFromDb = _db.Brand.FirstOrDefault(s => s.Id == brand.Id);

            objFromDb.Name =        brand.Name;
            objFromDb.Description = brand.Description;

            _db.SaveChanges();
        }
    }
}
