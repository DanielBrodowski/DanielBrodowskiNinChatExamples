﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using webshopbybrodowski.Contract.Product;
using webshopbybrodowski.Models;

namespace webshopbybrodowski.DataAccess.Data.Repository
{
    public class ProductRepository : Repository<Product> , IProductRepository
    {
        private readonly ApplicationDbContext _db;

        public ProductRepository(ApplicationDbContext db) : base(db)
        {
            _db = db;
        }

        public void Update(Product product)
        {
            var objFromDb = _db.Product.FirstOrDefault(s => s.Id == product.Id);

            objFromDb.Name = product.Name;
            objFromDb.Description = product.Description;
            objFromDb.Price = product.Price;
            objFromDb.ImageUrl = product.ImageUrl;
            objFromDb.BrandId = product.BrandId;
            objFromDb.CategoryId = product.CategoryId;

            _db.SaveChanges();
        }

    }
}
