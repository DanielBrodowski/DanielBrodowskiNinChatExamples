﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using webshopbybrodowski.Contract.User;
using webshopbybrodowski.Models;

namespace webshopbybrodowski.DataAccess.Data.Repository
{
    public class UserRepository : Repository<User>, IUserRepository
    {
        private readonly ApplicationDbContext _db;

        public UserRepository(ApplicationDbContext db) : base(db)
        {
            _db = db;
        }


        public void LockedUser(string id)
        {
            var userFromdb = _db.User.FirstOrDefault(u => u.Id == id);
            userFromdb.LockoutEnd = DateTime.Now.AddYears(1000);
            _db.SaveChanges();
        }

        public void UnlockUser(string id)
        {
            var userFromdb = _db.User.FirstOrDefault(u => u.Id == id);
            userFromdb.LockoutEnd = DateTime.Now;
            _db.SaveChanges();
        }
    }
}
