﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using webshopbybrodowski.Contract.Repository;

namespace webshopbybrodowski.DataAccess.Data.Repository
{
    public class Repository<T> : IRepository<T> where T : class //Generic repository implementing its interface
    {

        protected readonly DbContext Context; //Using EF default DbContext file
        internal DbSet<T> dbSet;

        //Injecting Dependencies and initializing
        public Repository(DbContext context)
        {
            Context = context;
            this.dbSet = context.Set<T>();
        }

        public void Add(T entity) //Add the generic to dbSet
        {
            dbSet.Add(entity); 
        }

        public T Get(int id) //retrieve dbSet based on id
        {
            return dbSet.Find(id);
        }

        public IEnumerable<T> GetAll(Expression<Func<T, bool>> filter = null, Func<IQueryable<T>, IOrderedEnumerable<T>> orderBy = null, string includeProperties = null)
        {
            IQueryable<T> query = dbSet;

            if (filter != null)
            {
                query = query.Where(filter);
            }
            //Separate properties with a comma!
            if (includeProperties != null)
            {
                foreach (var includeProperty in includeProperties.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries))
                {
                    query = query.Include(includeProperty);
                }
            }

            if (orderBy != null)
            {
                return orderBy(query).ToList();
            }
            return query.ToList();
        }

        public T GetFirstOrDefault(Expression<Func<T, bool>> filter = null, string includeProperties = null)
        {
            IQueryable<T> query = dbSet;

            if (filter != null)
            {
                query = query.Where(filter);
            }
            //Separate properties with a comma!
            if (includeProperties != null)
            {
                foreach (var includeProperty in includeProperties.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries))
                {
                    query = query.Include(includeProperty);
                }
            }

            return query.FirstOrDefault();
        }

        public void Remove(int id)
        {
            T entityToRemove = dbSet.Find(id); //Finding entity that will be removed first
            Remove(entityToRemove); //Remove the found entity from tables
        }

        public void Remove(T entity)
        {
            dbSet.Remove(entity); //If entity is passed as a whole there is no need to find it first can be removed straight away
        }
    }
}
