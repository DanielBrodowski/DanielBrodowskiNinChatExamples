﻿using System;
using System.Collections.Generic;
using System.Text;
using webshopbybrodowski.Contract.OrderDetails;
using webshopbybrodowski.Models;

namespace webshopbybrodowski.DataAccess.Data.Repository
{
    public class OrderDetailsRepository : Repository<OrderDetails>, IOrderDetailsRepository
    {
        private readonly ApplicationDbContext _db;

        public OrderDetailsRepository(ApplicationDbContext db) : base(db)
        {
            _db = db;
        }


    }
}
