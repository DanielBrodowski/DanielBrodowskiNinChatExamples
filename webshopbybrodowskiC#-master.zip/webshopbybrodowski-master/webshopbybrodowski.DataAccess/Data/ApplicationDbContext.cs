﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;
using webshopbybrodowski.Contract.Brand;
using webshopbybrodowski.Models;

namespace webshopbybrodowski.DataAccess.Data
{
    public class ApplicationDbContext : IdentityDbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {

        }

        public DbSet<Category> Category { get; set; }
        public DbSet<Brand> Brand { get; set; }
        public DbSet<Brand> BrandNew { get; set; }
        public DbSet<Product> Product { get; set; }
        public DbSet<OrderHeader> Order { get; set; }
        public DbSet<OrderDetails> OrderDetails { get; set; }
        public DbSet<User> User { get; set; }
    }
}
