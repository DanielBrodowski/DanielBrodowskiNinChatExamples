﻿using AutoMapper;
using System;
using System.Collections.Generic;
using System.Text;
using webshopbybrodowski.Contract.Order;
using webshopbybrodowski.Models;

namespace webshopbybrodowski.DataAccess.Profiles
{
    public class OrderProfile : Profile
    {
        public OrderProfile()
        {
            CreateMap<OrderHeader, OrderDto>();
            CreateMap<OrderDto, OrderHeader>();
        }
    }
}
