﻿using AutoMapper;
using System;
using System.Collections.Generic;
using System.Text;
using webshopbybrodowski.Contract.User;
using webshopbybrodowski.Models;

namespace webshopbybrodowski.DataAccess.Profiles
{
    public class UserProfile : Profile
    {
        public UserProfile()
        {
            CreateMap<UserDto, User>();

            CreateMap<User, UserDto>();
        }
    }
}
