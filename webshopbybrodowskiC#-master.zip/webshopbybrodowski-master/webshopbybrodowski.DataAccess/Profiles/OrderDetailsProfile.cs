﻿using AutoMapper;
using System;
using System.Collections.Generic;
using System.Text;
using webshopbybrodowski.Contract.OrderDetails;
using webshopbybrodowski.Models;

namespace webshopbybrodowski.DataAccess.Profiles
{
    public class OrderDetailsProfile : Profile
    {
        public OrderDetailsProfile()
        {
            CreateMap<OrderDetails, OrderDetailsDto>();
            CreateMap<OrderDetailsDto, OrderDetails>();
        }
    }
}
