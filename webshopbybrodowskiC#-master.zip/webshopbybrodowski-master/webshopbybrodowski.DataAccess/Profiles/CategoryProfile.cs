﻿using AutoMapper;
using webshopbybrodowski.Contract.Category;
using webshopbybrodowski.Models;

namespace webshopbybrodowski.DataAccess.Profiles
{
    public class CategoryProfile : Profile
    {
        public CategoryProfile()
        {
            CreateMap<Category, CategoryDto>();
            CreateMap<CategoryDto, Category>();
        }
    }
}
