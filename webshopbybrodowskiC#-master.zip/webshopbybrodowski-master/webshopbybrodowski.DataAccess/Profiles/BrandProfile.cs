﻿using AutoMapper;
using System;
using System.Collections.Generic;
using System.Text;
using webshopbybrodowski.Contract.Brand;
using webshopbybrodowski.Models;

namespace webshopbybrodowski.DataAccess.Profiles
{
    public class BrandProfile : Profile
    {
        public BrandProfile()
        {
            CreateMap<Brand, BrandDto>();
            CreateMap<BrandDto, Brand>();
        }
    }
}
