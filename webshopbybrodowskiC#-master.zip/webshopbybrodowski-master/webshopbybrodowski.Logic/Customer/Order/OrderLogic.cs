﻿using AutoMapper;
using System;
using System.Collections.Generic;
using System.Text;
using webshopbybrodowski.Contract.Order;
using webshopbybrodowski.Contract.OrderDetails;
using webshopbybrodowski.Contract.UnitOfWork;

namespace webshopbybrodowski.Logic.Customer.Order
{
    public class OrderLogic : IOrderLogic
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly IMapper _mapper;
       // private IEnumerable<OrderDto> order;

        public OrderLogic(IUnitOfWork unitOfWork, IMapper mapper)
        {
            _unitOfWork = unitOfWork;
            _mapper = mapper;
        }

        public OrderDto GetFirstOrDefault(OrderDto model)
        {
            var orderFromDb = _unitOfWork.Order.GetFirstOrDefault(order => order.Id == model.Id);
            var mapper = _mapper.Map<OrderDto>(orderFromDb);
            return mapper;
        }
        public OrderDto AddOrder(OrderDto model)
        {
            var orderFromDb = _mapper.Map<Models.OrderHeader>(model);

            _unitOfWork.Order.Add(orderFromDb);
            _unitOfWork.Save();

            return _mapper.Map<OrderDto>(orderFromDb);

            
        }
    }
}
