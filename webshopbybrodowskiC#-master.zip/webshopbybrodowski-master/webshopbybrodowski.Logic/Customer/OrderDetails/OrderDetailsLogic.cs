﻿using AutoMapper;
using System;
using System.Collections.Generic;
using System.Text;
using webshopbybrodowski.Contract.OrderDetails;
using webshopbybrodowski.Contract.UnitOfWork;

namespace webshopbybrodowski.Logic.Customer.OrderDetails
{
    public class OrderDetailsLogic : IOrderDetailsLogic
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly IMapper _mapper;

        public OrderDetailsLogic(IUnitOfWork unitOfWork, IMapper mapper)
        {
            _mapper = mapper;
            _unitOfWork = unitOfWork;
        }

        public OrderDetailsDto AddOrderDetails(OrderDetailsDto model)
        {
            var orderDetailFromDb = _mapper.Map<Models.OrderDetails>(model);

            _unitOfWork.OrderDetails.Add(orderDetailFromDb);
            _unitOfWork.Save();

            return _mapper.Map<OrderDetailsDto>(orderDetailFromDb);
        }
    }
}
