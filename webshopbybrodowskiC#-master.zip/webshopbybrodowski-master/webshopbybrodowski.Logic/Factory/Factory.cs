﻿using AutoMapper;
using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.Text;
using webshopbybrodowski.Contract.Factory;
using webshopbybrodowski.Contract.Identity;
using webshopbybrodowski.Logic.IdentityLogic;

namespace webshopbybrodowski.Logic.Factory
{
    public class Factory : IFactory
    {
        private readonly SignInManager<Models.User> _userInManager;
        private readonly RoleManager<IdentityRole> _roleManager;
        private readonly IMapper _mapper;
        private readonly UserManager<Models.User> _userManager;
        private readonly IRolesLogic _rolesLogic;

        public Factory(SignInManager<Models.User> signInManager, RoleManager<IdentityRole> roleManager,
                                                IMapper mapper, UserManager<Models.User> userManager, IRolesLogic rolesLogic)
        {

            _userInManager = signInManager;
            _roleManager = roleManager;
            _mapper = mapper;
            _userManager = userManager;
            _rolesLogic = rolesLogic;

            Register = new RegisterLogic(_userManager, _mapper, _userInManager, _rolesLogic);
            Login = new LoginLogic(_userInManager);
            LogOut = new LogOutLogic(_userInManager);
        }

        public IRegisterLogic Register { get; private set; }
        public ILoginLogic Login { get; private set; }
        public ILogOutLogic LogOut { get; private set; }

    }
}
