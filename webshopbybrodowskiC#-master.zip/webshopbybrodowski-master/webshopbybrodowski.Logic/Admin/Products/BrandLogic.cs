﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Text;
using webshopbybrodowski.Contract.Brand;
using webshopbybrodowski.Contract.UnitOfWork;
using webshopbybrodowski.Models;

namespace webshopbybrodowski.Logic.Admin.Product
{
    public class BrandLogic : IBrandLogic
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly IMapper _mapper;

        public BrandLogic(IUnitOfWork unitOfWork, IMapper mapper)
        {
            _unitOfWork = unitOfWork;
            _mapper = mapper;
        }

        public BrandDto Delete(int? id)
        {
            var items = _unitOfWork.Brand.Get(id.GetValueOrDefault());
            var map = _mapper.Map<BrandDto>(items);

            _unitOfWork.Brand.Remove(items);
            _unitOfWork.Save();
            return map;
        }

        public IEnumerable<BrandDto> GetAll()
        {
            var items = _unitOfWork.Brand.GetAll();
            return _mapper.Map<IEnumerable<BrandDto>>(items);
        }

        public IEnumerable<SelectListItem> GetDropDown()
        {
            var obj = _unitOfWork.Brand.GetBrandListForDropdown();
            return _mapper.Map<IEnumerable<SelectListItem>>(obj);
        }

        public BrandDto GetId(int? id)
        {
            var items = _unitOfWork.Brand.Get(id.GetValueOrDefault());

            return _mapper.Map<BrandDto>(items);

        }

        public BrandDto Upsert(BrandDto createBrandDto)
        {
            var brandModel = _mapper.Map<Brand>(createBrandDto);
            if (createBrandDto.Id == 0)
            {
                _unitOfWork.Brand.Add(brandModel);
            }
            else
            {
                _unitOfWork.Brand.Update(brandModel);
            }

            _unitOfWork.Save();
            return _mapper.Map<BrandDto>(brandModel);
        }
    }
}
