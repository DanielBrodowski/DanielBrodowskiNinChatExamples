﻿using AutoMapper;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using webshopbybrodowski.Contract.Product;
using webshopbybrodowski.Contract.UnitOfWork;

namespace webshopbybrodowski.Logic.Admin.Products
{
    public class ProductLogic : IProductLogic
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly IMapper _mapper;
        private readonly IWebHostEnvironment _webHostEnvironment;


        public ProductLogic(IUnitOfWork unitOfWork, IMapper mapper, IWebHostEnvironment webHostEnvironment)
        {
            _webHostEnvironment = webHostEnvironment;
            _unitOfWork = unitOfWork;
            _mapper = mapper;
        }

        public ProductDto CreateImagePath(ProductDto productDto, IFormFileCollection files)
        {

            string webRootPath = _webHostEnvironment.WebRootPath;
            
            if (files.Count > 0)
            {
                string filename = Guid.NewGuid().ToString();
                string uploadDirectory = Path.Combine(webRootPath, @"images\products");
                var extension = Path.GetExtension(files[0].FileName);

                if (productDto.ImageUrl != null)
                {
                    var imagePath = Path.Combine(webRootPath, productDto.ImageUrl.TrimStart('\\'));

                    if (System.IO.File.Exists(imagePath))
                    {
                        System.IO.File.Delete(imagePath);
                    }
                }

                using (var filesStream = new FileStream(Path.Combine(uploadDirectory, filename + extension), FileMode.Create))
                {
                    files[0].CopyTo(filesStream);
                }

                productDto.ImageUrl = @"\images\products\" + filename + extension;
            }
            else
            {
                if (productDto.Id != 0)
                {
                    var objFromDb = _unitOfWork.Product.Get(productDto.Id);
                    productDto.ImageUrl = objFromDb.ImageUrl;
                }
            }

            this.Upsert(productDto);
            return productDto;
        }

        public ProductDto Delete(int? id)
        {
            var objFromDb = _unitOfWork.Product.Get(id.GetValueOrDefault());

            var map = _mapper.Map<ProductDto>(objFromDb);

            _unitOfWork.Product.Remove(objFromDb);
            _unitOfWork.Save();

            return map;
        }

        public IEnumerable<ProductDto> GetAll()
        {
            var objFromDb = _unitOfWork.Product.GetAll(includeProperties: "Brand,Category");

            return _mapper.Map<IEnumerable < ProductDto >> (objFromDb);
        }

        public ProductDto GetFirstOrDefault(int? id)
        {
            var obj = _unitOfWork.Product.GetFirstOrDefault(u => u.Id == id, includeProperties: "Brand,Category");

            return _mapper.Map<ProductDto>(obj);
        }

        public ProductDto GetId(int? id)
        {
            var objFromDb = _unitOfWork.Product.Get(id.GetValueOrDefault());

            return _mapper.Map<ProductDto>(objFromDb);
        }

        public ProductDto Upsert(ProductDto productDto)
        {
            var productModel = _mapper.Map<Models.Product>(productDto);
            if (productDto.Id == 0)
            {
                _unitOfWork.Product.Add(productModel);
            }
            else
            {
                _unitOfWork.Product.Update(productModel);
            }

            _unitOfWork.Save();
            return _mapper.Map<ProductDto>(productModel);
        }
    }
}
