﻿using System;
using System.Collections.Generic;
using System.Text;
using AutoMapper;
using webshopbybrodowski.Models;
using Microsoft.AspNetCore.Mvc.Rendering;
using webshopbybrodowski.Contract.UnitOfWork;
using webshopbybrodowski.Contract.Category;

namespace webshopbybrodowski.Logic.Admin.Product
{
    public class CategoryLogic : ICategoryLogic
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly IMapper _mapper;

        public CategoryLogic(IUnitOfWork unitOfWork, IMapper mapper)
        {
            _unitOfWork = unitOfWork;
            _mapper = mapper;
        }

        public CategoryDto Delete(int? id)
        {
            var items = _unitOfWork.Category.Get(id.GetValueOrDefault());
            var map = _mapper.Map<CategoryDto>(items);

            _unitOfWork.Category.Remove(items);
            _unitOfWork.Save();
            return map;
        }

        public IEnumerable<CategoryDto> GetAll()
        {
            var items = _unitOfWork.Category.GetAll();
            return _mapper.Map<IEnumerable<CategoryDto>>(items);
        }



        public IEnumerable<SelectListItem> GetDropDown()
        {
            var obj = _unitOfWork.Category.GetCategoryListForDropdown();
            return _mapper.Map<IEnumerable<SelectListItem>>(obj);
        }

        public CategoryDto GetId(int? id)
        {
            var items = _unitOfWork.Category.Get(id.GetValueOrDefault());

            return _mapper.Map<CategoryDto>(items);

        }

        public CategoryDto Upsert(CategoryDto createCategoryDto)
        {
            var categoryModel = _mapper.Map<Category>(createCategoryDto);
            if (createCategoryDto.Id == 0)
            {
                _unitOfWork.Category.Add(categoryModel);
            }
            else
            {
                _unitOfWork.Category.Update(categoryModel);
            }

            _unitOfWork.Save();
            return _mapper.Map<CategoryDto>(categoryModel);
        }
    }
}
