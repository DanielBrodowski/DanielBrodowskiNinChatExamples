﻿using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.Text;
using webshopbybrodowski.Contract.Identity;

namespace webshopbybrodowski.Logic.IdentityLogic
{
   public class LogOutLogic : ILogOutLogic
    {
        private readonly SignInManager<Models.User> _signInManager;

        public LogOutLogic(SignInManager<Models.User> signInManager)
        {
            _signInManager = signInManager;
        }

        public void LogOutUser()
        {
            _signInManager.SignOutAsync();
        }
    }
}
