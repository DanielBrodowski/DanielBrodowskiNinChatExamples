﻿using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using webshopbybrodowski.Contract.Identity;

namespace webshopbybrodowski.Logic.IdentityLogic
{
    public class LoginLogic : ILoginLogic
    {
        private readonly SignInManager<Models.User> _signInManager;

        public LoginLogic(SignInManager<Models.User> signInManager)
        {
            _signInManager = signInManager;

        }

        public async Task<bool> Login(Models.User model)
        {
            var result = await _signInManager.PasswordSignInAsync(model.Email, model.PasswordHash, false, false);

            if (result.Succeeded)
            {
                return true;
            }
            return false;
        }
    }
}
