﻿using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using webshopbybrodowski.Contract.Identity;
using webshopbybrodowski.Utility;

namespace webshopbybrodowski.Logic.IdentityLogic
{
    public class RolesLogic : IRolesLogic
    {
        private readonly RoleManager<IdentityRole> _roleManager;
        private readonly UserManager<Models.User> _userManager;

        public RolesLogic(RoleManager<IdentityRole> roleManager, UserManager<Models.User> userManager)
        {
            _roleManager = roleManager;
            _userManager = userManager;
        }

        public void RolesCheck()
        {

            if (_roleManager.RoleExistsAsync(Roles.Admin) != null)
            {
                _roleManager.CreateAsync(new IdentityRole(Roles.Admin));
            }



            if (_roleManager.RoleExistsAsync(Roles.User) != null)
            {
                _roleManager.CreateAsync(new IdentityRole(Roles.User));
            }

        }


        public async Task<Models.User> AddToRole(Models.User user)
        {
            if (user.Role == null)
            {
                await _userManager.AddToRoleAsync(user, Roles.User);
            }
            else
            {
                await _userManager.AddToRoleAsync(user, user.Role);
            }

            return user;
        }
    }
}
