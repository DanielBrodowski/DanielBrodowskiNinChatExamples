﻿using AutoMapper;
using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using webshopbybrodowski.Contract.Identity;

namespace webshopbybrodowski.Logic.IdentityLogic
{
    public class RegisterLogic : IRegisterLogic
    {
        private readonly UserManager<Models.User> _userManager;
        private readonly IMapper _mapper;
        private readonly SignInManager<Models.User> _signInManager;

        private readonly IRolesLogic _rolesLogic;

        public RegisterLogic(UserManager<Models.User> userManager, IMapper mapper, SignInManager<Models.User> signInManager, IRolesLogic rolesLogic)
        {
            _userManager = userManager;
            _mapper = mapper;
            _signInManager = signInManager;
            _rolesLogic = rolesLogic;
        }

        public async Task<Models.User> SignUp(Models.User model)
        {

            if (await _userManager.FindByEmailAsync(model.Email) == null)
            {
                var user = new Models.User()
                {
                    Email = model.Email,
                    UserName = model.Email,
                    Role = model.Role,
                    EmailConfirmed = true,
                };

                var result = await _userManager.CreateAsync(user, model.PasswordHash);

                if (result.Succeeded)
                {
                    await _rolesLogic.AddToRole(user);

                    await _signInManager.SignInAsync(user, false);

                    return model;
                }

                var sa = result.Errors.Select(a => a.Description);

            }
            return model;
        }
    }
}
