﻿using AutoMapper;
using System;
using System.Collections.Generic;
using System.Text;
using webshopbybrodowski.Contract.UnitOfWork;
using webshopbybrodowski.Contract.User;

namespace webshopbybrodowski.Logic.User
{
   public class UserDetailsLogic : IUserDetailsLogic
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly IMapper _mapper;

        public UserDetailsLogic(IUnitOfWork unitOfWork, IMapper mapper)
        {
            _unitOfWork = unitOfWork;
            _mapper = mapper;
        }

        public UserDto GetFirstOfDefault(string id)
        {
            var obj = _unitOfWork.User.GetFirstOrDefault(u => u.Id == id);

            return _mapper.Map<UserDto>(obj);
        }
    }
}
