using AutoMapper;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using webshopbybrodowski.Contract.Brand;
using webshopbybrodowski.Contract.Category;
using webshopbybrodowski.Contract.Order;
using webshopbybrodowski.Contract.OrderDetails;
using webshopbybrodowski.Contract.Product;
using webshopbybrodowski.Contract.UnitOfWork;
using webshopbybrodowski.Contract.User;
using webshopbybrodowski.DataAccess.Data.Repository;
using webshopbybrodowski.Models;
using webshopbybrodowski.Utility;

namespace webshopbybrodowski.Tests
{
    [TestClass]
    public class MainTests
    {
        private readonly IUnitOfWork _sut;
        private readonly Mock<IBrandRepository> _brandRepoMock = new Mock<IBrandRepository>();

        public MainTests()
        {
           // _sut = new IUnitOfWork(_brandRepoMock.);
        }

        [TestMethod]
        public void Adding_Product_To_Cart()
        {
            
        }

        public class UnitOfWork : IUnitOfWork
        {
            public ICategoryRepository Category => throw new System.NotImplementedException();

            public IBrandRepository Brand => throw new System.NotImplementedException();

            public IProductRepository Product => throw new System.NotImplementedException();

            public IOrderHeaderRepository Order => throw new System.NotImplementedException();

            public IOrderDetailsRepository OrderDetails => throw new System.NotImplementedException();

            public IUserRepository User => throw new System.NotImplementedException();

            public void Save()
            {
                throw new System.NotImplementedException();
            }
        }

        public class BrandRepo : IBrandRepository
        {
            public void Add(Brand entity)
            {
                throw new NotImplementedException();
            }

            public Brand Get(int id)
            {
                return new Brand { Id = 1, Description = "test", Name = "test", ImageUrl = "test" };
            }

            public IEnumerable<Brand> GetAll(Expression<Func<Brand, bool>> filter = null, Func<IQueryable<Brand>, IOrderedEnumerable<Brand>> orderBy = null, string includeProperties = null)
            {
                throw new NotImplementedException();
            }

            public IEnumerable<SelectListItem> GetBrandListForDropdown()
            {
                throw new NotImplementedException();
            }

            public Brand GetFirstOrDefault(Expression<Func<Brand, bool>> filter = null, string includeProperties = null)
            {
                throw new NotImplementedException();
            }

            public void Remove(int id)
            {
                throw new NotImplementedException();
            }

            public void Remove(Brand entity)
            {
                throw new NotImplementedException();
            }

            public void Update(Brand brand)
            {
                throw new NotImplementedException();
            }
        }

    }
}
