﻿using AutoMapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using webshopbybrodowski.Areas.Admin.ViewModels;
using webshopbybrodowski.Models;

namespace webshopbybrodowski.Profiles
{
    public class UserProfile : Profile
    {
        public UserProfile()
        {
            CreateMap<SignUpViewModel, User>();
            CreateMap<User, SignUpViewModel>();

            CreateMap<SignInViewModel, User>();
            CreateMap<User, SignInViewModel>();
        }
    }
}
