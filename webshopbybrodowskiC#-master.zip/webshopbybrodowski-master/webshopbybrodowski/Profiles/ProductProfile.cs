﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using webshopbybrodowski.Areas.Admin.ViewModels;
using webshopbybrodowski.Areas.Customer.ViewModels;
using webshopbybrodowski.Contract.Product;

namespace webshopbybrodowski.Profiles
{
    public class ProductProfile : AutoMapper.Profile
    {
        public ProductProfile()
        {
            CreateMap<ProductViewModel, ProductDto>();
            CreateMap<ProductDto, ProductViewModel>();

            //Customer
            CreateMap<HomeViewModel, ProductDto>();
            CreateMap<ProductDto, HomeViewModel>();
        }
    }
}
