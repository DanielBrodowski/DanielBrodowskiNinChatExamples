﻿using webshopbybrodowski.Areas.Admin.ViewModels;
using webshopbybrodowski.Contract.Brand;

namespace webshopbybrodowski.Profiles
{
    public class BrandProfile : AutoMapper.Profile
    {
        public BrandProfile()
        {
            CreateMap<BrandViewModel, BrandDto>();
            CreateMap<BrandDto, BrandViewModel>();
        }
    }
}
