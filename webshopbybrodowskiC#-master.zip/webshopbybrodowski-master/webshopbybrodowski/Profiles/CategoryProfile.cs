﻿using webshopbybrodowski.Areas.Admin.ViewModels;
using webshopbybrodowski.Contract.Category;


namespace webshopbybrodowski.Areas.Profiles
{
    public class CategoryProfile : AutoMapper.Profile
    {
        public CategoryProfile()
        {
            CreateMap<CategoryViewModel, CategoryDto>();
            CreateMap<CategoryDto, CategoryViewModel>();
        }
    }
}
