﻿var dataTable;

$(document).ready(function () {
    loadDataTable();
});

function loadDataTable() {
    dataTable = $('#tblDataProduct').DataTable({
        "ajax": {
            "url": "/admin/product/GetAll",
            "type": "GET",
            "datatype": "json"
        },
        "columns": [
            { "data": "name" },
            { "data": "price" },
            { "data": "category.name" },
            { "data": "brand.name" },
            {
                "data": "id",
                "render": function (data) {
                    return `<div class="text-center">
                                <a href="/Admin/Product/Upsert/${data}" class="btn btn-success" style="cursor:pointer; margin-right: 15px;">
                                    <i class='far fa-edit'></i> Edit
                                </a>
                                
                                <a onclick=Delete("/Admin/Product/Delete/${data}") class="btn btn-danger" style="cursor:pointer;">
                                    <i class='far fa-trash-alt'></i> Delete
                                </a>
                            </div>
                            `;
                }, "width": "30%"
            }
        ],
        "language": {
            "emptyTable": "No records found."
        },
        "width": "100%"
    });
}

function Delete(url) {
    swal({
        title: "Delete the current Product?",
        text: "This action is non-reversable.",
        type: "warning",
        showCancelButton: true,
        confirmButtonColor: "#DD6B55",
        confirmButtonText: "Confirm",
        closeOnConfirm: true
    }, function () {
        $.ajax({
            type: 'DELETE',
            url: url,
            success: function (data) {
                if (data.success) {
                    toastr.success(data.message);
                    dataTable.ajax.reload();
                }
                else {
                    toastr.error(data.message);
                }
            }
        });
    });
}

function ShowMessage(msg) {

}