﻿using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using webshopbybrodowski.Areas.Customer.ViewModels;
using webshopbybrodowski.Contract.Order;
using webshopbybrodowski.Contract.OrderDetails;
using webshopbybrodowski.Contract.Product;
using webshopbybrodowski.Contract.User;
using webshopbybrodowski.Extensions;
using webshopbybrodowski.Utility;

namespace webshopbybrodowski.Areas.Customer.Controllers
{
    [Area("Customer")]
    public class CartController : Controller
    {
        private readonly IMapper _mapper;
        private readonly IProductLogic _productLogic;
        private readonly IOrderLogic _orderLogic;
        private readonly IOrderDetailsLogic _orderDetailsLogic;
        private readonly IUserDetailsLogic _userDetails;

        [BindProperty]
        private CartViewModel CartVM { get; set; }

        public CartController(IProductLogic productLogic, IMapper mapper, IOrderLogic orderLogic, IOrderDetailsLogic orderDetailsLogic, IUserDetailsLogic userDetailsLogic)
        {
            _productLogic = productLogic;
            _mapper = mapper;
            _orderLogic = orderLogic;
            _orderDetailsLogic = orderDetailsLogic;
            _userDetails = userDetailsLogic;

            CartVM = new CartViewModel()
            {
                Order = new OrderDto(),
                ProductList = new List<ProductDto>()
            };
        }

        public List<int> HttpSession()
        {
            var sessions = HttpContext.Session.GetObject<List<int>>(Session.SessionCart);
            if (HttpContext.Session.GetObject<List<int>>(Session.SessionCart) != null)
            {
                foreach (var productId in sessions)
                {
                    var productFromDb = _productLogic.GetFirstOrDefault(productId);
                    var mapperProduct = _mapper.Map<ProductDto>(productFromDb);

                    CartVM.ProductList.Add(mapperProduct);
                }
            }

            return sessions;
        }

        public Claim GetUserClaim()
        {
            var claimsIdentity = (ClaimsIdentity)User.Identity;
            var claim = claimsIdentity.FindFirst(ClaimTypes.NameIdentifier);


            return claim;
        }

        public IActionResult Index()
        {
            HttpSession();

            return View(CartVM);
        }

        [Authorize]
        public IActionResult Summary()
        {
            var userClaim = GetUserClaim();
            CartVM.User = _userDetails.GetFirstOfDefault(userClaim.Value);

            HttpSession();

            return View(CartVM);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        //[ActionName("Summary")]
        public IActionResult SummaryPost(CartViewModel model)
        {
            CartVM = new CartViewModel
            {
                ProductList = new List<ProductDto>(),
                Order = new OrderDto(),
            };

            HttpSession();

            if (ModelState.IsValid)
            {
                foreach (var product in CartVM.ProductList)
                {
                    CartVM.Order.Total += product.Price;
                }

                CartVM.OrderDate = model.OrderDate;
                CartVM.Order.UserId = GetUserClaim().Value;

                _orderLogic.AddOrder(CartVM.Order);

                foreach (var product in CartVM.ProductList)
                {
                    CartVM.Order.Total += product.Price;

                    var orderDetails = new OrderDetailsDto
                    {
                        ProductId = product.Id,
                        OrderId = CartVM.Order.Id,
                        Price = product.Price
                    };

                    _orderDetailsLogic.AddOrderDetails(orderDetails);

                }
                return RedirectToAction("OrderConfirmation", "Cart", new { id = CartVM.Order.Id });
            }
            return View(CartVM);
        }

        public IActionResult OrderConfirmation(int id)
        {
            return View(id);
        }

        public IActionResult Remove(int productId)
        {
            List<int> sessionList = new List<int>();
            sessionList = HttpContext.Session.GetObject<List<int>>(Session.SessionCart);
            sessionList.Remove(productId);
            HttpContext.Session.SetObject(Session.SessionCart, sessionList);

            return RedirectToAction(nameof(Index));
        }
    }
}
