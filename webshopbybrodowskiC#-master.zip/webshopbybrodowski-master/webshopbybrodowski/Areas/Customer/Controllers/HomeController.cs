﻿using AutoMapper;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using webshopbybrodowski.Areas.Admin.ViewModels;
using webshopbybrodowski.Areas.Customer.ViewModels;
using webshopbybrodowski.Contract.Brand;
using webshopbybrodowski.Contract.Category;
using webshopbybrodowski.Contract.Product;
using webshopbybrodowski.Extensions;
using webshopbybrodowski.Logic;
using webshopbybrodowski.Models;
using webshopbybrodowski.Utility;

namespace webshopbybrodowski.Controllers
{
    [Area("Customer")]
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly ICategoryLogic _categoryLogic;
        private readonly IProductLogic _productLogic;
        private readonly IBrandLogic _brandLogic;
        private readonly IMapper _mapper;


        public HomeController(ILogger<HomeController> logger, ICategoryLogic categoryLogic, IProductLogic productLogic, IBrandLogic brandLogic, IMapper mapper)
        {
            _logger = logger;
            _categoryLogic = categoryLogic;
            _productLogic = productLogic;
            _brandLogic = brandLogic;
            _mapper = mapper;
        }

        public IActionResult Index()
        {
            var HomeVM = new HomeViewModel()
            {
                Categories = _categoryLogic.GetAll(),
                Products = _productLogic.GetAll(),
                Brands = _brandLogic.GetAll()
            };

            return View(HomeVM);
        }

        public IActionResult Details(int? id)
        {
            var productFromDb = _productLogic.GetFirstOrDefault(id);
            //var viewModel = _mapper.Map<HomeViewModel>(productFromDb);

            return View(_mapper.Map<HomeViewModel>(productFromDb));
        }

        public IActionResult AddToCart(int productId)
        {
            List<int> sessionList = new List<int>();
            if (string.IsNullOrEmpty(HttpContext.Session.GetString(Session.SessionCart)))
            {
                sessionList.Add(productId);
                HttpContext.Session.SetObject(Session.SessionCart, sessionList);
            }
            else
            {
                sessionList = HttpContext.Session.GetObject<List<int>>(Session.SessionCart);
                if (!sessionList.Contains(productId))
                {
                    sessionList.Add(productId);
                    HttpContext.Session.SetObject(Session.SessionCart, sessionList);
                }
            }

            return RedirectToAction(nameof(Index));
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
