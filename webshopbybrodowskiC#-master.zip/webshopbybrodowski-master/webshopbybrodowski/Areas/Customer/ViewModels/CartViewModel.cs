﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using webshopbybrodowski.Contract.Order;
using webshopbybrodowski.Contract.Product;
using webshopbybrodowski.Contract.User;

namespace webshopbybrodowski.Areas.Customer.ViewModels
{
    public class CartViewModel
    {
        public int Id { get; set; }
        public IList<ProductDto> ProductList { get; set; }
        public ProductDto Product { get; set; }
        public int ProductId { get; set; }
        public string UserId { get; set; }
        public UserDto User { get; set; }
        public OrderDto Order { get; set; }
        public DateTime OrderDate { get; set; }
    }
}
