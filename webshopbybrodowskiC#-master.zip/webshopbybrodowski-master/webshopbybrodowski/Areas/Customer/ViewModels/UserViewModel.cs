﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace webshopbybrodowski.Areas.Customer.ViewModels
{
    public class UserViewModel
    {
        public string Email { get; set; }
        public string Id { get; set; }

        public string Phonenumber { get; set; }
        public string Firstname { get; set; }
        public string Surname { get; set; }
        public string Address { get; set; }
        public string Residence { get; set; }
        public string Postalcode { get; set; }
        public string Housenumber { get; set; }
    }
}
