﻿using AutoMapper;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using webshopbybrodowski.Areas.Admin.ViewModels;
using webshopbybrodowski.Contract.Factory;
using webshopbybrodowski.Models;
using webshopbybrodowski.Utility;

namespace webshopbybrodowski.Areas.Admin.Controllers
{
    [Area("Admin")]
    public class IdentityController : Controller
    {
        private readonly SignInManager<User> _signInManager;
        private readonly RoleManager<IdentityRole> _roleManager;
        private readonly IMapper _mapper;
        private readonly IFactory _factory;

        public IdentityController(SignInManager<User> signInManager, RoleManager<IdentityRole> roleManager, IMapper mapper, IFactory factory)
        {
            _signInManager = signInManager;
            _roleManager = roleManager;
            _mapper = mapper;
            _factory = factory;
        }
        
        public IActionResult SignUp()
        {
            var model = new SignUpViewModel
            {
                RoleList = _roleManager.Roles.Where(u => u.Name != Roles.User).Select(i => new SelectListItem
                {
                    Text = i.Name,
                    Value = i.Name
                })
            };

            return View(model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> SignUp(SignUpViewModel signUpViewModel)
        {
            if (ModelState.IsValid)
            {
                var mapper = _mapper.Map<User>(signUpViewModel);

                await _factory.Register.SignUp(mapper);
            }


            return RedirectToAction("SignIn");
        }

        public IActionResult SignIn()
        {
            var model = new SignInViewModel();
            if (_signInManager.IsSignedIn(User))
            {
                return RedirectToAction("Index", "Home", new { area = "Customer" });
            }

            return View(model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> SignIn(SignInViewModel model)
        {
            if (ModelState.IsValid)
            {
                var mapper = _mapper.Map<User>(model);
                var result = await _factory.Login.Login(mapper);

                if (result == false)
                {
                    ModelState.AddModelError("Login", "Incorrect email or password");
                    return View(model);
                }
                return RedirectToAction("Index", "Home", new { area = "Customer" });
            }
            return View(model);
        }

        public IActionResult AccessDenied()
        {
            return View();
        }

        public async Task<IActionResult> LogOut()
        {
            _factory.LogOut.LogOutUser();
            return RedirectToAction("SignIn");
        }

    }
}
