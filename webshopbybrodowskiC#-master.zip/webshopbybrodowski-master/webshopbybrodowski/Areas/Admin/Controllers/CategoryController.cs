﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using webshopbybrodowski.Areas.Admin.ViewModels;
using webshopbybrodowski.Contract.Category;
using webshopbybrodowski.Logic;
using webshopbybrodowski.Models;

namespace webshopbybrodowski.Areas.Admin.Controllers
{
    [Area("Admin")]
    public class CategoryController : Controller
    {
        private readonly IMapper _mapper;
        private readonly ICategoryLogic _categoryLogic;

        public CategoryController(IMapper mapper, ICategoryLogic categoryLogic)
        {
            _mapper = mapper;
            _categoryLogic = categoryLogic;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Upsert(int? id)
        {
            var category = new CategoryViewModel();

            if (id == null)
            {
                return View(category);
            }

            var obj = _categoryLogic.GetId(id);
            var viewmodel = _mapper.Map<CategoryViewModel>(obj);

            if (obj == null)
            {
                return NotFound();
            }
            return View(viewmodel);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Upsert(CategoryViewModel category)
        {
            if (ModelState.IsValid)
            {
                var mapper = _mapper.Map<CategoryDto>(category);
                _categoryLogic.Upsert(mapper);
            }

            return RedirectToAction("Index");
        }

        #region API Calls

        [HttpGet]
        public IActionResult GetAll()
        {
            return Json(new { data = _categoryLogic.GetAll() });
        }

        [HttpDelete]
        public IActionResult Delete(int id)
        {
            var objFromDb = _categoryLogic.GetId(id);

            if (objFromDb == null)
            {
                return Json(new { success = false, message = "Category could not be deleted." });
            }

            _categoryLogic.Delete(objFromDb.Id);

            return Json(new { success = true, message = "Category deleted successfully" });
        }

        #endregion

    }
}
