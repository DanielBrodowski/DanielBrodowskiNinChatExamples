﻿using AutoMapper;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using webshopbybrodowski.Areas.Admin.ViewModels;
using webshopbybrodowski.Contract.Brand;
using webshopbybrodowski.Contract.Category;
using webshopbybrodowski.Contract.Product;
using webshopbybrodowski.Logic;

namespace webshopbybrodowski.Areas.Admin.Controllers
{
    [Area("Admin")]
    public class ProductController : Controller
    {
        private readonly IBrandLogic _brandLogic;
        private readonly ICategoryLogic _categoryLogic;
        private readonly IMapper _mapper;
        private readonly IProductLogic _productLogic;

        [BindProperty] public ProductViewModel ProductViewModel { get; set; }

        public ProductController(IBrandLogic brandLogic, ICategoryLogic categoryLogic, IMapper mapper,
            IProductLogic productLogic)
        {
            _brandLogic = brandLogic;
            _categoryLogic = categoryLogic;
            _mapper = mapper;
            _productLogic = productLogic;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Upsert(int? id)
        {

            if (id == null)
            {
                ProductViewModel = new ProductViewModel
                {
                    BrandList = _brandLogic.GetDropDown(),
                    CategoryList = _categoryLogic.GetDropDown()

                };

                return View(ProductViewModel);
            }

            var obj = _productLogic.GetId(id);  
            ProductViewModel = _mapper.Map<ProductViewModel>(obj);
            ProductViewModel.BrandList = _brandLogic.GetDropDown();
            ProductViewModel.CategoryList = _categoryLogic.GetDropDown();

            return View(ProductViewModel);

        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Upsert(ProductViewModel productViewModel)
        {
            if (ModelState.IsValid)
            {
                var files = HttpContext.Request.Form.Files;
                var mapper = _mapper.Map<ProductDto>(productViewModel);
                var obj = _productLogic.CreateImagePath(mapper, files);

                ProductViewModel = _mapper.Map<ProductViewModel>(obj);
                return RedirectToAction(nameof(Index));
            }

            ProductViewModel.BrandList = _brandLogic.GetDropDown();
            ProductViewModel.CategoryList = _categoryLogic.GetDropDown();

            return View(ProductViewModel);
        }

        #region API Calls

        [HttpGet]
        public IActionResult GetAll()
        {
            return Json(new { data = _productLogic.GetAll() });
        }

        [HttpDelete]
        public IActionResult Delete(int id)
        {
            var productFromDb = _productLogic.GetId(id);
            if (productFromDb == null)
            {
                return Json(new { success = false, message = "Error while deleting" });
            }

            _productLogic.Delete(productFromDb.Id);
            return Json(new { success = true, message = $"Delete succesful {id}" });
        }

        #endregion
    }
}
