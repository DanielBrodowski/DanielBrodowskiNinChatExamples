﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using webshopbybrodowski.Areas.Admin.ViewModels;
using webshopbybrodowski.Contract.Brand;

namespace webshopbybrodowski.Areas.Admin.Controllers
{
    [Area("Admin")]
    public class BrandController : Controller
    {
        private readonly IMapper _mapper;
        private readonly IBrandLogic _brandLogic;

        public BrandController(IMapper mapper, IBrandLogic brandLogic)
        {
            _mapper = mapper;
            _brandLogic = brandLogic;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Upsert(int? id)
        {
            var brand = new BrandViewModel();

            if (id == null)
            {
                return View(brand);
            }

            var obj = _brandLogic.GetId(id);
            var viewmodel = _mapper.Map<BrandViewModel>(obj);

            if (obj == null)
            {
                return NotFound();
            }
            return View(viewmodel);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Upsert(BrandViewModel brand)
        {
            if (ModelState.IsValid)
            {
                var mapper = _mapper.Map<BrandDto>(brand);
                _brandLogic.Upsert(mapper);
            }

            return RedirectToAction("Index");
        }


        #region API Calls

        [HttpGet]
        public IActionResult GetAll()
        {
            return Json(new { data = _brandLogic.GetAll() });
        }

        [HttpDelete]
        public IActionResult Delete(int id)
        {
            var objFromDb = _brandLogic.GetId(id);

            if (objFromDb == null)
            {
                return Json(new { success = false, message = "Brand could not be deleted." });
            }

            _brandLogic.Delete(objFromDb.Id);

            return Json(new { success = true, message = "Brand deleted successfully" });
        }

        #endregion
    }
}
