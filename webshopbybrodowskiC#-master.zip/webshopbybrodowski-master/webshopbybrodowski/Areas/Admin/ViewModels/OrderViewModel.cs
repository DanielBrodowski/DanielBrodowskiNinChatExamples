﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using webshopbybrodowski.Contract.Order;
using webshopbybrodowski.Contract.OrderDetails;

namespace webshopbybrodowski.Areas.Admin.ViewModels
{
    public class OrderViewModel
    {
        public OrderDto Order { get; set; }
        public IEnumerable<OrderDetailsDto> OrderDetails { get; set; }
    }
}
