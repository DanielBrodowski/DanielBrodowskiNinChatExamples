﻿using System;
using System.Collections.Generic;
using System.Text;

namespace webshopbybrodowski.Areas.Admin.Service
{
    public class SmtpOptions
    {
        public string Host { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
        public int Port { get; set; }
    }
}
