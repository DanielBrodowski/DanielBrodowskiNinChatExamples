﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace webshopbybrodowski.Areas.Admin.Service
{
    public interface IEmailSender
    {
        Task SendEmailAsync(string fromAddress, string toAddress, string subject, string message);
    }
}
